# pylint: disable= C0103,C0301
""" Test cases for GitHub Connection"""
import json
import pytest
from payload_generator.github.github_connection import GitHubController
from payload_generator.commons.errors import ConnectivityException, ValidationException

secret_access_key = open("resources/urlpath/secret_access_key.txt", "r").read()
url = open("resources/urlpath/githubpath", "r").read()

def test_is_branch_name_correct():
    """test to check the branch name is correct or not"""
    repo = "jains16/fdet398"
    branch_name = "incorrect_branch_name"
    gitcont = GitHubController(url, secret_access_key, repo)
    with pytest.raises(ValidationException):
        assert gitcont.fetch_files_from_branch(branch_name)

def test_is_git_content_present():
    "test to check is git connent is present or not"
    repo = "jains16/fdet398"
    branch_name = "CIO45678"
    gitcont = GitHubController(url, secret_access_key, repo)
    content = gitcont.fetch_files_from_branch(branch_name)
    if len(content) > 0:
        assert True

def test_git_connection():
    "test to check is connection established or not"
    repo = "jains16/fdet39"
    with pytest.raises(ConnectivityException):
        assert GitHubController(url, secret_access_key, repo)

def test_is_fetch_files_from_branch():
    "test to check correct values are fetch from branch"
    repo = "jains16/fdet398"
    branch_name = "CIO45678"
    sampleContent = json.load(open('resources/github-test-files/sample_git_file_from_branch.json', 'r'))
    gitcont = GitHubController(url, secret_access_key, repo)
    content = gitcont.fetch_files_from_branch(branch_name)
    if content == sampleContent:
        assert True

def test_is_fetch_files_from_branch_for_specific_folder():
    "test to check correct values are fetch from folder in branch"
    repo = "jains16/fdet398"
    branch_name = "CIO45678"
    sampleContent = json.load(open('resources/github-test-files/sample_git_file_from_branch_for_folder.json', 'r'))
    folder_name = "idam"
    gitcont = GitHubController(url, secret_access_key, repo)
    content = gitcont.fetch_files_from_branch(branch_name, folder_name)
    if content == sampleContent:
        assert True
