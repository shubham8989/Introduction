""" Module to test s3 CRUD opoerations - +ve and -ve cases"""
import os
import pytest
from moto import mock_s3
from payload_generator.repositories.s3_repositories import(
    WorkspaceDefinitionRepository
)
from payload_generator.clients.aws_clients import(get_s3_client, get_s3_bucket)

FOLDER_NAME = 'CM09876545'
FOLDER_NAME1 = 'TEMP'
OBJECT_NAME = 'workspace_payload.json'
OBJECT_NAME1 = 'idam.txt'
TEMP_FOLDER = 'temp_result'
NONE_FOLDER_NAME = None
BUCKET_NAME = os.getenv('WORKSPACE_DEFINITION_REPO', 'workspace-def-repo')

@pytest.mark.dependency()
def test_s3_create_folder():
    """ Method to test create folder"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        for key in s3_bucket.objects.all():
            if key.key == f'{FOLDER_NAME}/':
                folder_present = True
                break
        assert folder_present is True

@pytest.mark.dependency(depends=["test_s3_operarion_create_folder"])
def test_s3_save_file_in_folder():
    """ Method to test - save file in a folder"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        if not os.path.exists(TEMP_FOLDER):
            os.mkdir(TEMP_FOLDER)
        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'w') as file_write:
            file_write.write('This is a sample file ')

        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb') as file_object:
            model_instance.save_file_in_folder_s3(FOLDER_NAME, OBJECT_NAME, file_object)

        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb') as file_object:
            model_instance.save_file_in_folder_s3(FOLDER_NAME, OBJECT_NAME1, file_object)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        for key in s3_bucket.objects.all():
            if key.key == f'{FOLDER_NAME}/{OBJECT_NAME}':
                file1_present = True
                continue
            if key.key == f'{FOLDER_NAME}/{OBJECT_NAME1}':
                file2_present = True
                continue
        assert file1_present is True and file2_present is True

@pytest.mark.dependency(
        depends=["test_s3_create_folder",
                 "test_s3_save_file_in_folder"]
    )
def test_s3_save_file():
    """ Method to test - save file in a bucket"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb') as file_object:
            model_instance.save_file_s3(OBJECT_NAME1, file_object)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        for key in s3_bucket.objects.all():
            if key.key == f'{OBJECT_NAME1}':
                file_present = True
                break
        assert file_present is True

@pytest.mark.dependency(
        depends=["test_s3_create_folder",
                 "test_s3_save_file_in_folder",
                 "test_s3_save_file"]
    )
def test_s3_search():
    """ Method to test - seach file/folder in a bucket"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME)
        if not os.path.exists(TEMP_FOLDER):
            os.mkdir(TEMP_FOLDER)
        file_object = open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'w')
        file_object.write('This is a sample file ')
        file_object.close()
        file_object = open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb')
        model_instance.save_file_in_folder_s3(FOLDER_NAME, OBJECT_NAME, file_object)
        file_object.close()

        searched_object = model_instance.search_file_s3(FOLDER_NAME, OBJECT_NAME)

        searched_object1 = model_instance.search_file_s3(FOLDER_NAME)

        s3_bucket = get_s3_bucket(BUCKET_NAME)
        for key in s3_bucket.objects.all():
            if key.key == f'{FOLDER_NAME}/{OBJECT_NAME}':
                file_present = True
                break
        assert file_present is True
        first = []
        first.append(f'{FOLDER_NAME}/{OBJECT_NAME}')
        assert first == searched_object
        assert f'{FOLDER_NAME}/' in searched_object1
#        assert f'{OBJECT_NAME1}' in searched_object2

@pytest.mark.dependency(
        depends=["test_s3_create_folder",
                 "test_s3_save_file_in_folder",
                 "test_s3_save_file",
                 "test_s3_search"]
    )
def test_s3_update_file():
    """ Method to test - update a  file in a folder"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME)
        with open(os.path.join(TEMP_FOLDER, 'sample1.txt'), 'w') as file_write:
            file_write.write('Changed content ')
        with open(os.path.join(TEMP_FOLDER, 'sample1.txt'), 'rb') as file_object:
            model_instance.save_file_s3(OBJECT_NAME1, file_object)

        with open(os.path.join(TEMP_FOLDER, 'sample1.txt'), 'w') as file_write:
            file_write.write('Changed content for folder')
        with open(os.path.join(TEMP_FOLDER, 'sample1.txt'), 'rb') as file_object:
            model_instance.update_file_in_folder_s3(
                FOLDER_NAME,
                OBJECT_NAME1,
                file_object
            )
        searched_object2 = model_instance.search_file_s3(NONE_FOLDER_NAME, OBJECT_NAME1)
        assert f'{OBJECT_NAME1}' in searched_object2

@pytest.mark.dependency(
        depends=["test_s3_create_folder",
                 "test_s3_save_file_in_folder",
                 "test_s3_save_file",
                 "test_s3_search"]
    )
def test_s3_delete_file_from_folder():
    """ Method to test - delete a file from a folder"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME)
        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'w') as file_write:
            file_write.write('This is a sample file ')

        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb') as file_object:
            model_instance.save_file_in_folder_s3(FOLDER_NAME, OBJECT_NAME1, file_object)

        with open(os.path.join(TEMP_FOLDER, 'sample.txt'), 'rb') as file_object:
            model_instance.save_file_s3(OBJECT_NAME1, file_object)
        model_instance.delete_file_from_folder_s3(FOLDER_NAME, OBJECT_NAME1)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        for key in s3_bucket.objects.all():
            if key.key == f'{FOLDER_NAME}/{OBJECT_NAME1}':
                file_present = True
            else:
                file_present = False
            if file_present:
                break
        assert file_present is False


def test_s3_delete_folder():
    """ Method to test - delete a folder"""
    with mock_s3():
        create_s3_bucket_for_testing()
        model_instance = WorkspaceDefinitionRepository()
        model_instance.create_folder_s3(FOLDER_NAME1)
        s3_bucket = get_s3_bucket(BUCKET_NAME)
        model_instance.delete_folder_s3(FOLDER_NAME1)
        file_present = False
        for key in s3_bucket.objects.all():
            if key.key == f'{FOLDER_NAME1}/':
                file_present = True
                break
        assert file_present is False


def create_s3_bucket_for_testing():
    """get s3 s3 bucket object and return"""
    with mock_s3():
        s3client = get_s3_client()
        if not s3client.Bucket(BUCKET_NAME) in s3client.buckets.all():
            s3client.create_bucket(Bucket=BUCKET_NAME)
