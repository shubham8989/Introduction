"""This module is for processing of of Idam files ."""
import os
import glob
import json
import shutil
import ast
import pytest
from payload_generator.workspace.workspace_payload_generator import WorkspacePayloadGenerator
from payload_generator.workspace.payload_matcher import WorkspacePayloadComparator
from payload_generator.commons.util import extract_cinumber_from_workspace_def

from payload_generator.commons.errors import ValidationException

BASE_LOC = os.path.join('resources', 'workspace_payload.json')
CONFIG_LOC = os.path.join('resources', 'config', 'workspace_param_definition.json')
CONFIG_NESTED_LOC = os.path.join(
    'resources', 'config', 'workspace_param_definition_nested_config.json'
)
OUT_LOC = os.path.join('temp_results')


@pytest.fixture
def workspace_json():
    """ For opening  workspace payload jason file"""
    return json.load(open(BASE_LOC, 'rb'))

@pytest.fixture
def config_json():
    """ For opening  config payload json file"""
    return json.load(open(CONFIG_LOC, 'rb'))

@pytest.fixture
def config_nested_json():
    """ For opening  config payload json file"""
    return json.load(open(CONFIG_NESTED_LOC, 'rb'))

def test_is_process_workspace_works(workspace_json, config_json):
    """This func used for testing of creation of workspace payload."""
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    process_workspace.process_workspace_payload(workspace_json, config_json, OUT_LOC)
    assert len(glob.glob(f'{OUT_LOC}/*.json')) > 0
    compare_json = WorkspacePayloadComparator()
    exchange = {}
    exchange['errors'] = []
    out_json = output_json(workspace_json)
    assert len(glob.glob(f'{OUT_LOC}/*.json')) > 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) > 0:
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        assert len(exchange['errors']) == 1 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors'])
    temp_folders = glob.glob('temp*')
    for folder in temp_folders:
        if os.path.exists(folder):
            shutil.rmtree(folder)

def test_ws_def_missing_mandatory_field(workspace_json, config_json):
    """ The case where a mandatory parameter is missing """
    del workspace_json['repo_name']
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    with pytest.raises(ValidationException):
        assert process_workspace.process_workspace_payload(workspace_json, config_json, OUT_LOC)
    assert len(glob.glob(f'{OUT_LOC}/*.json')) == 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) == 1:
        compare_json = WorkspacePayloadComparator()
        exchange = {}
        exchange['errors'] = []
        out_json = output_json(workspace_json)
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        assert len(exchange['errors']) == 2 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors']) and\
                '[root -> repo_name]' in\
                ''.join(exchange['errors'])

def test_workspace_missing_list_element(workspace_json, config_json):
    """ The positive case for testing the workspace param validations """
    del workspace_json['workspace_administrator'][0]['user_name']
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    with pytest.raises(ValidationException):
        assert process_workspace.process_workspace_payload(workspace_json, config_json, OUT_LOC)
    assert len(glob.glob(f'{OUT_LOC}/*.json')) == 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) == 1:
        compare_json = WorkspacePayloadComparator()
        exchange = {}
        exchange['errors'] = []
        out_json = output_json(workspace_json)
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        assert len(exchange['errors']) == 2 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors']) and \
                '[root -> workspace_administrator -> [0] -> user_name]' in\
                ''.join(exchange['errors'])

def test_workspace_incorrect_value(workspace_json, config_json):
    """ The positive case for testing the workspace param validations """
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    process_workspace.process_workspace_payload(workspace_json, config_json, OUT_LOC)
    assert len(glob.glob(f'{OUT_LOC}/*.json')) > 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) > 0:
        compare_json = WorkspacePayloadComparator()
        exchange = {}
        exchange['errors'] = []
        out_json = output_json(workspace_json)
        out_json['workspace_administrator'][0]['user_name'] = "XYZ"
        out_json['workspace_administrator'][0]['user_email'] = "XYZ@a.com"
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        assert len(exchange['errors']) == 3 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors']) and\
            '[root -> workspace_administrator -> [0] -> user_name]' in\
            ''.join(exchange['errors']) and\
            '[root -> workspace_administrator -> [0] -> user_email]' in\
            ''.join(exchange['errors'])
        temp_folders = glob.glob('temp*')
        for folder in temp_folders:
            if os.path.exists(folder):
                shutil.rmtree(folder)


def test_workspace_nested_element_in_config(workspace_json, config_nested_json):
    """ The positive case for testing nested elements in config """
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    with pytest.raises(ValidationException):
        assert process_workspace.process_workspace_payload(
            workspace_json,
            config_nested_json,
            OUT_LOC
        )
    assert len(glob.glob(f'{OUT_LOC}/*.json')) == 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) == 1:
        compare_json = WorkspacePayloadComparator()
        exchange = {}
        exchange['errors'] = []
        out_json = output_json(workspace_json)
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        print(f' errors -> {exchange}')
        assert len(exchange['errors']) == 2 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors']) and\
                '[root -> repo_name]' in\
                ''.join(exchange['errors'])

def test_workspace_nested_element_in_config_ws(workspace_json, config_nested_json):
    """ The positive case for testing nested elements in config """
    if not os.path.exists(OUT_LOC):
        os.mkdir(OUT_LOC)
    process_workspace = WorkspacePayloadGenerator()
    addln_value = "[{'inner-params': {'inne-inner-param': 23}}]"
    workspace_json['myparam'] = ast.literal_eval(addln_value)
    print(workspace_json)
    process_workspace.process_workspace_payload(
        workspace_json,
        config_nested_json,
        OUT_LOC
    )
    assert len(glob.glob(f'{OUT_LOC}/*.json')) > 0
    if len(glob.glob(f'{OUT_LOC}/*.json')) == 1:
        compare_json = WorkspacePayloadComparator()
        exchange = {}
        exchange['errors'] = []
        out_json = output_json(workspace_json)
        compare_json.compare_payloads(workspace_json, out_json, exchange)
        print(f' errors -> {exchange}')
        assert len(exchange['errors']) == 1 and \
            '[root -> workspace_email]' \
            in ''.join(exchange['errors'])


def output_json(workspace_json):
    """ For opening  workspace payload json file"""
    ci_number = extract_cinumber_from_workspace_def(workspace_json)
    ci_number = ci_number[2:]
    file_name = f'workspace_{ci_number}.json'
    output_json_file = os.path.join(OUT_LOC, file_name)
    out_json = json.load(open(output_json_file, 'rb'))
    return out_json
