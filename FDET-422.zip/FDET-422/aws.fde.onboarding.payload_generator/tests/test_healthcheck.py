""" Testing the healthcheck """

from payload_generator.services.healthcheck_service import HealthcheckService

def test_payload_creation_integration(mocker):
    """ Test that healthcheck text is correct """
    timestamp_mock = mocker.patch(
        'payload_generator.services.healthcheck_service.HealthcheckService._generate_timestamp',
        return_value="1970-01-01 00:00:00"
    )
    service = HealthcheckService()
    response = service.check_health()

    timestamp_mock.assert_called_once()
    assert response == "Healthy as of: 1970-01-01 00:00:00"
