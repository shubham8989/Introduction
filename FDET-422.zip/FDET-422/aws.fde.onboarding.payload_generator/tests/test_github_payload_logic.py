""" This module contains test cases for git workflow """
import pytest
from payload_generator.github.github_payload_controller import GithubPayloadController
from payload_generator.commons.errors import ValidationException
from tests.test_utils import (
    create_sub_structure_positive,
    create_sub_structure_ws_validation,
    data_for_git_mock_side_effect
)

def test_does_flow_work(mocker, github_client):
    """ Tests the positive flow """
    mocker.patch(
        'payload_generator.github.github_client.GithubClient.clone_repo',
        side_effect=create_sub_structure_positive
    )
    base_folder, request_id = data_for_git_mock_side_effect()
    process_controller = GithubPayloadController(github_client)
    ci_number = process_controller.start_process(request_id, base_folder)
    assert ci_number == 'CM0929076'

def test_is_missing_ws_payload_validated(mocker, github_client):
    """ Tests negative flow and error handling """
    base_folder, request_id = data_for_git_mock_side_effect()
    mocker.patch(
        'payload_generator.github.github_client.GithubClient.clone_repo',
        side_effect=create_sub_structure_ws_validation
    )
    process_controller = GithubPayloadController(github_client)
    with pytest.raises(ValidationException):
        process_controller.start_process(request_id, base_folder)
