""" This module defines all the test related utility functions """

import os
import shutil

def create_sub_structure_positive(host, branch, destination):
    """ Stub """
    create_sub_structure(branch=branch, with_payload=True)

def create_sub_structure_ws_validation(host, branch, destination):
    """ Stub """
    create_sub_structure(branch=branch, with_payload=False)

def create_sub_structure(branch, with_payload):
    """ Stub """
    base_folder, request_id = data_for_git_mock_side_effect()
    if not os.path.exists(base_folder):
        os.mkdir(base_folder)
    if branch == request_id:
        if not os.path.exists(f'{base_folder}/{request_id}'):
            os.mkdir(f'{base_folder}/{request_id}')
        if with_payload:
            shutil.copyfile(
                'resources/workspace_payload.json',
                f'{base_folder}/{request_id}/cba-a-pr-0929076-dpg-prd-cyber_securit.json'
            )
    elif branch.startswith('CM'):
        shutil.copytree('resources/idam', f'{base_folder}/{branch}/idam/idam-vro-payload/')

def data_for_git_mock_side_effect():
    """ Returns the test data for the git logic tests"""
    return ('temp_test_folder', 'REQ1321176')

def create_design_substructure(host, branch, destination):
    """Stub"""
    base_folder = 'temp_design_doc_folder'
    if not os.path.exists(base_folder):
        os.mkdir(base_folder)
    if not os.path.exists(f'{base_folder}/{branch}'):
        os.mkdir(f'{base_folder}/{branch}')
    if not os.path.exists(f'{base_folder}/{branch}/config'):
        os.mkdir(f'{base_folder}/{branch}/config')
    shutil.copyfile(
        'resources/design-samples/metadata.json',
        f'{base_folder}/{branch}/config/metadata.json'
    )
    shutil.copyfile(
        'resources/design-samples/workspace_requirements.json',
        f'{base_folder}/{branch}/config/workspace_requirements.json'
    )
