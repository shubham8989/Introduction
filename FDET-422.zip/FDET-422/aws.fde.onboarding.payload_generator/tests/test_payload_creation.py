""" Testing the payload creation flow"""

import os
import glob
from payload_generator.services.payload_service import PayloadService
from tests.test_utils import (
    create_sub_structure_positive,
    data_for_git_mock_side_effect
)

def test_payload_creation_integration(mocker):
    """ The positive test case, testing the full flow """
    base_folder, request_id = data_for_git_mock_side_effect()
    mocker.patch(
        'payload_generator.github.github_client.GithubClient.clone_repo',
        side_effect=create_sub_structure_positive
    )
    os.environ['VCS_BASE_DIRECTORY'] = base_folder
    payload_service = PayloadService()
    payload_service.start_payloads_generations(request_id)
    assert os.path.exists(f'{base_folder}/CM0929076/output')
    idam_archieve = glob.glob(f'{base_folder}/CM0929076/output/*.zip')
    assert 'Idamfiles_CM0929076' in idam_archieve[0]
    assert len(glob.glob(f'{base_folder}/CM0929076/output/*.json')) > 0

def test_invalid_request_id():
    """ The negative case with invalid ID """
    payload_service = PayloadService()
    output = payload_service.start_payloads_generations('CMTestTets')
    assert 'ValidationException' in output['error']['message']
