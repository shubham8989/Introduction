""" Test cases for SMTP email sending """
from payload_generator.notification.smtp_controller import SMTPController
# import pytest

RECEIVERS = ['receiver1@cba.com.au', 'receiver2@cba.com.au']
MESSAGE = 'Some Text'

def test_smtp_success(mocker):
    """ Test that SMTP library is correctly utilised """
    mocker.patch(
        'payload_generator.commons.constants'
    )
    mocker.patch(
        'os.environ',
        return_value={'SMTP_USER' : 'testuser', 'SMTP_PASSWORD' : 'testpassword'}
    )
    ssl_context = mocker.patch(
        'ssl._create_unverified_context'
    )
    server = mocker.patch(
        'smtplib.SMTP'
    )
    controller = SMTPController()
    controller.send_email(RECEIVERS, MESSAGE)
    ssl_context.assert_called_once()
    server.assert_called_once()
