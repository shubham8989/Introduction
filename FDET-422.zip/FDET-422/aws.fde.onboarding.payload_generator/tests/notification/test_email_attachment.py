""" TestCases for email attachment """
import pytest
from payload_generator.notification.email_controller import EmailController
from payload_generator.commons.errors import OperationsException

TEMPLATE = 'sent_to_team'
ATTACHMENT_1 = ['resources/test.txt']
ATTACHMENT_2 = "this is attachment"
ATTACHMENT_3 = ['resources/test.jpg']
RECEIVERS_1 = ['receiver1@cba.com.au', 'receiver2@cba.com.au']
RECEIVERS_2 = ['receiver3@cba.com.au', 'receiver4@cba.com.au']

EXPECTED_MESSAGE_1 = """
Content-Type: text/plain
Content-Transfer-Encoding: base64
Content-Disposition: attachment; filename="test.txt"
MIME-Version: 1.0

VGhpcyBpcyB0ZXN0IGZpbGUgZm9yIGF0dGFjaG1lbnQgaW4gZW1haWw=
"""

EXPECTED_MESSAGE_2 = """Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: 7bit
MIME-Version: 1.0
Subject:
 45 - Request for workspace TEST23 has been submitted to the StillTesting team
From: no-reply@cba.com.au
To: receiver3@cba.com.au, receiver4@cba.com.au
Cc: receiver1@cba.com.au, receiver2@cba.com.au

This is a test e-mail message related to 45 - TEST23.
"""

PAYLOAD_1 = {
    'CI_NUMBER' : '1234567891',
    'WORKSPACE_NAME' :  'TEST1',
    'TEAM_NAME' : 'Testing'
}

PAYLOAD_2 = {
    'CI_NUMBER' : '45',
    'WORKSPACE_NAME' :  'TEST23',
    'TEAM_NAME' : 'StillTesting'
}

def test_is_message_correct():
    """ Test that email body changes values correctly """
    controller = EmailController()

    email_1 = controller.construct_email(
        RECEIVERS_1, RECEIVERS_2, TEMPLATE, PAYLOAD_1, ATTACHMENT_1
    )
    email_2 = controller.construct_email(
        RECEIVERS_2, RECEIVERS_1, TEMPLATE, PAYLOAD_2
    )
    assert EXPECTED_MESSAGE_1 in str(email_1.get('message'))  \
        and str(email_2.get('message')) == EXPECTED_MESSAGE_2

def test_is_attachment_not_list():
    """ Test the type of attachment"""
    controller = EmailController()
    with pytest.raises(OperationsException) as exc:
        controller.construct_email(
            RECEIVERS_1, RECEIVERS_2, TEMPLATE, PAYLOAD_1, ATTACHMENT_2
            )
    exception_raised = exc.value
    assert "Expected attachments as list" in str(exception_raised)

def test_size_of_attachment():
    """ Test the type of attachment"""
    controller = EmailController()
    with pytest.raises(OperationsException) as exc:
        controller.construct_email(
            RECEIVERS_1, RECEIVERS_2, TEMPLATE, PAYLOAD_1, ATTACHMENT_3
            )
    exception_raised = exc.value
    assert "exceeded more than 1MB" in str(exception_raised)
