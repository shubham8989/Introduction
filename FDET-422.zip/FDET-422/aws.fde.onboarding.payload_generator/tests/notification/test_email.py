""" Test cases for email body and receivers generation """
from payload_generator.notification.email_controller import EmailController
""" TODO: Extract common email testing code and re-enable linting """
TEMPLATE = 'sent_to_team'

EXPECTED_MESSAGE_1 = """Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: 7bit
MIME-Version: 1.0
Subject:
 123456789 - Request for workspace TEST has been submitted to the Testing team
From: no-reply@cba.com.au
To: receiver1@cba.com.au, receiver2@cba.com.au
Cc: receiver3@cba.com.au, receiver4@cba.com.au

This is a test e-mail message related to 123456789 - TEST.
"""

EXPECTED_MESSAGE_2 = """Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: 7bit
MIME-Version: 1.0
Subject:
 456 - Request for workspace TEST2 has been submitted to the StillTesting team
From: no-reply@cba.com.au
To: receiver3@cba.com.au, receiver4@cba.com.au
Cc: receiver1@cba.com.au, receiver2@cba.com.au

This is a test e-mail message related to 456 - TEST2.
"""
EXPECTED_MESSAGE_3 = """Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: 7bit
MIME-Version: 1.0
Subject:
 123456789 - Request for workspace TEST has been submitted to the Testing team
From: no-reply@cba.com.au
To: receiver_s_1@cba.com.au
Cc: receiver_s_2@cba.com.au

This is a test e-mail message related to 123456789 - TEST.
"""


RECEIVERS_1 = ['receiver1@cba.com.au', 'receiver2@cba.com.au']
RECEIVERS_2 = ['receiver3@cba.com.au', 'receiver4@cba.com.au']
EXPECTED_RECEIVERS_1 = [
    'receiver1@cba.com.au',
    'receiver2@cba.com.au',
    'receiver3@cba.com.au',
    'receiver4@cba.com.au'
]
EXPECTED_RECEIVERS_2 = [
    'receiver3@cba.com.au',
    'receiver4@cba.com.au',
    'receiver1@cba.com.au',
    'receiver2@cba.com.au'
]

RECEIVER_1 = ['receiver_s_1@cba.com.au']
RECEIVER_2 = ['receiver_s_2@cba.com.au']

EXPECTED_RECEIVERS_3 = [
    'receiver_s_1@cba.com.au',
    'receiver_s_2@cba.com.au',
]

PAYLOAD_1 = {
    'CI_NUMBER' : '123456789',
    'WORKSPACE_NAME' :  'TEST',
    'TEAM_NAME' : 'Testing'
}
PAYLOAD_2 = {
    'CI_NUMBER' : '456',
    'WORKSPACE_NAME' :  'TEST2',
    'TEAM_NAME' : 'StillTesting'
}

""" TODO : Test non-array receivers, rename variables """

def test_is_message_correct():
    """ Test that email body changes values correctly """
    controller = EmailController()

    email_1 = controller.construct_email(
        RECEIVERS_1, RECEIVERS_2, TEMPLATE, PAYLOAD_1
    )
    email_2 = controller.construct_email(
        RECEIVERS_2, RECEIVERS_1, TEMPLATE, PAYLOAD_2
    )
    email_3 = controller.construct_email(
        RECEIVER_1, RECEIVER_2, TEMPLATE, PAYLOAD_1
    )
    assert str(email_1.get('message')) == EXPECTED_MESSAGE_1 \
        and str(email_2.get('message')) == EXPECTED_MESSAGE_2 \
        and str(email_3.get('message')) == EXPECTED_MESSAGE_3

def test_is_receivers_correct():
    """ Test that email receivers are generated correctly """
    controller = EmailController()

    email_1 = controller.construct_email(
        RECEIVERS_1, RECEIVERS_2, TEMPLATE, PAYLOAD_1
    )
    email_2 = controller.construct_email(
        RECEIVERS_2, RECEIVERS_1, TEMPLATE, PAYLOAD_2
    )
    email_3 = controller.construct_email(
        RECEIVER_1, RECEIVER_2, TEMPLATE, PAYLOAD_1
    )
    assert email_1.get('receivers') == EXPECTED_RECEIVERS_1 \
        and email_2.get('receivers') == EXPECTED_RECEIVERS_2 \
        and email_3.get('receivers') == EXPECTED_RECEIVERS_3
