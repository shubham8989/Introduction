"""This is test validation file"""
import json
import glob
import pytest
from payload_generator.validator.payload_validator import PayloadValidator
from payload_generator.commons.util import load_files_contents_dict

@pytest.fixture
def workspace_json():
    """ For opening  workspace payload jason file"""
    file = open('resources/workspace_payload.json', 'r')
    contents = file.read()
    return json.loads(contents)

@pytest.fixture
def idam_files():
    """ For opening IDAM files """
    files = glob.glob('resources/idam/*.csv')
    return load_files_contents_dict(files)

@pytest.fixture
def invalid_idam_files(idam_files):
    """ Test for the invalid IDAM files """
    idam_file_name = 'resources/idam/18_ProductDependencies0929076.csv'
    idam_file_value = idam_files[idam_file_name]
    del idam_files[idam_file_name]
    idam_files[idam_file_name.replace('0929076', '0929077')] = idam_file_value
    return idam_files

@pytest.fixture
def corrupted_idam_file():
    """ function creating corrupted files"""
    files = glob.glob('resources/idam/*.csv')
    idam_content = {}
    for f_num in files:
        file = open(f_num, 'r')
        file_contents = file.read()
        f_num = f_num.replace('0929076', '0929077')
        file = file_contents.replace('0929076', '0929077')
        idam_content[f_num] = file
    idam_file_name = 'resources/idam/01_Category0929077.csv'
    del idam_content[idam_file_name]
    return idam_content

@pytest.fixture
def workspace_param_definitions():
    """ Correct ws def config file """
    return json.load(open('resources/config/workspace_param_definition.json', 'rb'))

@pytest.fixture
def ws_def_imbal_list():
    """ WS config file with imbalanced list"""
    return json.load(open('resources/config/workspace_param_definition_inbal_lists.json', 'rb'))

def test_is_validation_works_for_positive(workspace_json, idam_files):
    """ Positive test case with exact data"""
    payload_validator = PayloadValidator()
    exchange = payload_validator.start_validation(workspace_json, idam_files)
    assert len(exchange['errors']) <= 0

def test_is_validation_picks_incorrect_idam_file(workspace_json, corrupted_idam_file):
    """ Negative test case to check for incorerct idam file name"""
    payload_validator = PayloadValidator()
    exchange = payload_validator.start_validation(workspace_json, corrupted_idam_file)
    assert len(exchange['errors']) >= 1 and any('Found irrelevant IDAM file' in error_list \
        for error_list in exchange['errors'])

def test_is_idam_file_doesnt_have_ci_number(workspace_json, corrupted_idam_file):
    """ Negative test case with idam file with incoorect ci number"""
    payload_validator = PayloadValidator()
    exchange = payload_validator.start_validation(workspace_json, corrupted_idam_file)
    assert len(exchange['errors']) >= 1 and any('Could not find CI_Number' in error_list \
        for error_list in exchange['errors'])

def test_is_idam_file_present(workspace_json, corrupted_idam_file):
    """ Negative test case with incorrect idam file"""
    payload_validator = PayloadValidator()
    exchange = payload_validator.start_validation(workspace_json, corrupted_idam_file)
    assert len(exchange['errors']) >= 1 and any('Could not find the IDAM file:' in error_list \
        for error_list in exchange['errors'])

def test_workspace_has_mandatory_params(workspace_json, idam_files, workspace_param_definitions):
    """ The positive case for testing the workspace param validations """
    validation_controller = PayloadValidator()
    exchange = validation_controller.start_validation(
        workspace_json,
        idam_files,
        workspace_param_definitions
    )
    assert len(exchange['errors']) == 0

def test_workspace_def_lists_validated(workspace_json, idam_files, ws_def_imbal_list):
    """ The negative case where lists have imbalanced params  """
    validation_controller = PayloadValidator()
    exchange = validation_controller.start_validation(workspace_json, idam_files, ws_def_imbal_list)
    assert len(exchange['errors']) == 10 and \
        '[root -> CustomProperties -> [0] -> ChangeRequestTasks]' \
        in ''.join(exchange['errors'])

def test_ws_def_missing_mandatory_field(workspace_json, idam_files, workspace_param_definitions):
    """ The case where a mandatory parameter is missing """
    validation_controller = PayloadValidator()
    del workspace_json['repo_name']
    exchange = validation_controller.start_validation(
        workspace_json,
        idam_files,
        workspace_param_definitions
    )
    assert len(exchange['errors']) == 1 and '[root -> repo_name]' in exchange['errors'][0]

def test_workspace_missing_list_element(workspace_json, idam_files, workspace_param_definitions):
    """ The positive case for testing the workspace param validations """
    del workspace_json['workspace_administrator'][0]['user_name']
    validation_controller = PayloadValidator()
    exchange = validation_controller.start_validation(
        workspace_json,
        idam_files,
        workspace_param_definitions
    )
    assert len(exchange['errors']) == 1 and \
        '[root -> workspace_administrator -> [0] -> user_name]' \
        in ''.join(exchange['errors'])
