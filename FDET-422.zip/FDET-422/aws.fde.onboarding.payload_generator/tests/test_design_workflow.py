""" The test module to check the design workflow """

import glob
import os
from payload_generator.services.design_validation_service import DesignValidationService
from tests.test_utils import create_design_substructure

def test_design_workflow(mocker):
    """ Tests the design workflow """
    mocker.patch(
        'payload_generator.github.github_client.GithubClient.clone_repo',
        side_effect=create_design_substructure
    )
    os.environ['DESIGN_DOCS_BASE_DIRECTORY'] = 'temp_design_doc_folder'
    design_validator = DesignValidationService()
    request_id = design_validator.start_design_validation('CM564567')
    assert request_id == 'REQ5774467'
    assert len(glob.glob('temp_design_doc_folder/CM564567/output')) > 0
