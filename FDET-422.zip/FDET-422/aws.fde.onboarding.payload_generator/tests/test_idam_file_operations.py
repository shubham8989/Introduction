"""This module is for processing of of Idam files ."""
import glob
import os
import pytest
from payload_generator.commons.errors import OperationsException
from payload_generator.idam.idam_files_processor import IdamFilesProcessor

SRC_LOC = os.path.join('resources', 'idam')
ZIP_LOC = os.path.join('temp_results')
SRC_LOC_INVALID = os.path.join('resources', 'test_idam')
ZIP_LOC_INVALID = os.path.join('resources', 'invalid_loc')
CI_NUMBER = '0929076'
INVALID_NUMBER = '0929078'

def test_is_file_process_works():
    """This func used for testing of renaming IDAM files."""
    process_files = IdamFilesProcessor()
    if not os.path.exists(ZIP_LOC):
        os.mkdir(ZIP_LOC)
    process_files.rename_compress_idamfiles(SRC_LOC, ZIP_LOC, CI_NUMBER)
    assert len(glob.glob(ZIP_LOC)) > 0

def test_is_file_process_works_invalid_src():
    """This func used for testing of renaming IDAM files."""
    with pytest.raises(OperationsException):
        process_files = IdamFilesProcessor()
        if not os.path.exists(ZIP_LOC):
            os.mkdir(ZIP_LOC)
        process_files.rename_compress_idamfiles(SRC_LOC_INVALID, ZIP_LOC, CI_NUMBER)
    assert len(glob.glob(ZIP_LOC)) > 0

def test_is_file_process_works_invalid_zip_dir():
    """This func used for testing of renaming IDAM files."""
    with pytest.raises(OperationsException):
        process_files = IdamFilesProcessor()
        process_files.rename_compress_idamfiles(SRC_LOC, ZIP_LOC_INVALID, CI_NUMBER)
    assert len(glob.glob(ZIP_LOC_INVALID)) == 0

def test_is_file_process_works_invalid_src_dir_n_invalid_ci_number():
    """This func used for testing of renaming IDAM files."""
    with pytest.raises(OperationsException):
        process_files = IdamFilesProcessor()
        if not os.path.exists(ZIP_LOC):
            os.mkdir(ZIP_LOC)
        process_files.rename_compress_idamfiles(SRC_LOC_INVALID, ZIP_LOC, INVALID_NUMBER)
    assert len(glob.glob(ZIP_LOC)) > 0
