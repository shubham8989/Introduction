""" Test cases to test the github integrartion on design """
import json
from payload_generator.validator.design_validator import DesignValidator

def test_mandatory_params_exist():
    """ Checks if the manadatory params are validated """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(open('resources/design-samples/metadata.json', 'r')),
        json.load(open('resources/design-samples/workspace_requirements.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    print(exchange['errors'])
    assert len(exchange['errors']) == 0

def test_incomplete_metadata_file_identified():
    """ Tests whether the incomplete metadata identified """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(
            open('resources/design-samples/metadata_incomplete.json', 'r')),
        json.load(
            open('resources/design-samples/workspace_requirements.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    assert len(exchange['errors']) == 1 and \
        'root -> workspace -> total_max_number_of_other_components' \
            in '--'.join(exchange['errors'])

def test_incomplete_ws_req_file_identified():
    """ Test to identify incomplete ws_req """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(
            open('resources/design-samples/metadata.json', 'r')),
        json.load(
            open('resources/design-samples/workspace_requirements_incomplete.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    assert len(exchange['errors']) == 1 and \
        'root -> zone_cidr_sizes -> ecvf' \
            in '--'.join(exchange['errors'])

def test_zero_secure_zone():
    """ Adding zero to secure zone """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(
            open('resources/design-samples/metadata.json', 'r')),
        json.load(
            open('resources/design-samples/workspace_requirements_nosecure.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    assert len(exchange['errors']) == 1 and \
        'Invalid size size allocated for secure zone' \
            in '--'.join(exchange['errors'])

def test_insufficient_secure_zone():
    """ Different security zones """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(
            open('resources/design-samples/metadata.json', 'r')),
        json.load(
            open('resources/design-samples/workspace_requirements_insufficient_secure.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    assert len(exchange['errors']) == 1 and \
        'Insufficient CIDR size for secure zone' \
            in '--'.join(exchange['errors'])

def test_cidr_requirements():
    """ Different CIDRs """
    design_validator = DesignValidator()
    exchange = design_validator.start_validations(
        json.load(
            open('resources/design-samples/metadata.json', 'r')),
        json.load(
            open('resources/design-samples/workspace_requirements_variable_cidr.json', 'r')),
        'CM123456789',
        {
            'metadata_config' : json.load(
                open('resources/config/design_metadata_template.json', 'r')),
            'ws_req_config' : json.load(
                open('resources/config/workspace_requirements.json', 'r'))
        }
    )
    assert len(exchange['errors']) == 2 and \
        'Invalid CIDR Size [/32] for [internally_controlled]' \
            in '--'.join(exchange['errors']) and \
                'Invalid CIDR definition [28] for [management]'\
                    in '--'.join(exchange['errors'])
