"""module to do cleanup activity"""
import os
import shutil
import glob
import pytest
from payload_generator.github.github_client import GithubClient

BASE_FOLDER = 'temp_test_folder'
REQUEST_ID = 'REQ1321176'

def pytest_sessionfinish(session, exitstatus):
    """ whole test run finishes. """
    idam_session_finish()

def idam_session_finish():
    """ idam temp files cleanup. """
    temp_folders = glob.glob('temp*')
    for folder in temp_folders:
        if os.path.exists(folder):
            shutil.rmtree(folder)

@pytest.fixture
def github_client():
    """ Instantiates the git client """
    client = GithubClient()
    return client
