# pylint: disable=R0903, W0231
""" Module used to fetch config file and return as variable """
from abc import ABCMeta
from payload_generator.commons.errors import OperationsException

class Config(metaclass=ABCMeta):
    """Interface for defining fetch config method"""
    def __init__(self):
        self.config = ""

    def fetch_config_file(self):
        """ method to fetch config file"""
        if not self.config:
            raise OperationsException(f'{self.__class__.__name__} - config cannot be empty')
        return self.config

class MetaDataConfig(Config):
    """ Class used for fetching design metadata template"""
    def __init__(self):
        self.config = {
            "request": {
                "ci-number": True,
                "request_it_id": True
            },
            "requestor" : {
                "requestor_name": True,
                "requestor_email": True,
                "staff_number": True
            },
            "workspace": {
                "preferred_name": True,
                "data_classification": True,
                "purpose": True,
                "total_max_number_of_application_components": True,
                "total_max_number_of_database_components": True,
                "total_max_number_of_other_components": True,
                "describe_other_components": False,
                "running_containers": True,
                "scaling_requirements": True
            },
            "containers_cluster_configuration": False,
            "metadata": False
        }


class WorkspaceParamDef(Config):
    """ Class used for fetching workspace param definition"""
    def __init__(self):
        self.config = {
            "requestor_type": False,
            "requested_by": [
                {
                    "requestor_name": False,
                    "requestor_email": False,
                    "requestor_staff_number": False,
                    "requestor_lan_id_domain": False,
                    "department_name": False
                }
            ],
            "requested_for": False,
            "approved_by": False,
            "approved_on": False,
            "project_name": False,
            "cost_centre": False,
            "business_justification": False,
            "group_entity": False,
            "business_group_manager": False,
            "req_number": False,
            "ritm_number": False,
            "service_ci": False,
            "application_ci": False,
            "number_of_workspaces": False,
            "cloud_platform": True,
            "service_provider": True,
            "service_environment": True,
            "application_environment": True,
            "virtual_appliance": False,
            "hosted_zone_description": True,
            "existing_custom_repo": True,
            "repo_name": True,
            "connectivity_to_cba_system": False,
            "aws_link_size": True,
            "ecmc_workspace": False,
            "azure_link_size": True,
            "email_distribution": True,
            "data_classification": True,
            "cyber_criticality": True,
            "hosts_per_zone": [
                {
                    "internally_controlled_hosts": True,
                    "restricted_hosts": False,
                    "secured_hosts": False,
                    "management_hosts": False,
                    "externally_controlled_if_hosts": False,
                    "externally_controlled_vpc_hosts": False
                }
            ],
            "attachment": False,
            "tra_id": False,
            "functional_soft_limit": False,
            "workspace_description": True,
            "workspace_administrator": [
                {
                    "user_name": True,
                    "user_email": True,
                    "user_staff_number": False,
                    "user_lan_id_domain": False
                }
            ],
            "workspace_power_user": True,
            "workspace_user": True,
            "server_administrator": True,
            "server_power_user": True,
            "server_user": True,
            "CustomProperties": True
        }

class WsRequirementTemplate(Config):
    """ Class used for fetching workspace requirement template"""
    def __init__(self):
        self.config = {
            "zone_cidr_sizes": {
                "internally_controlled": True,
                "restricted": True,
                "secured": True,
                "management": True,
                "ecif": True,
                "ecvf": True
            },
            "need_to_connect_to_bank": True,
            "peering_required_workspces": False,
            "TGW_configured": False
        }


class FetchConfig():
    """ factory class used to fetch all config files"""
    @staticmethod
    def get_config(config_type):
        """  method  to call config fetching classes """
        try:
            if config_type == "MetaDataConfig":
                return MetaDataConfig().fetch_config_file()
            if config_type == "WorkspaceParamDef":
                return WorkspaceParamDef().fetch_config_file()
            if config_type == "WsRequirementTemplate":
                return WsRequirementTemplate().fetch_config_file()
            raise OperationsException(f'Unsupported config type [{config_type}]')
        except Exception as exc:
            raise OperationsException(f'Error fetching the configurations for [{config_type}]', exc)
