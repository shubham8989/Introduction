"""Test intrigation Module"""
import os
import shutil
import glob
import pytest
from payload_generator.github.github_client import  GithubClient
from payload_generator.commons.errors import ConnectivityException

def test_is_github_cns_connectivity_works():
    """ Testing for github connectivity"""
    folder_name = 'test_clone_repo_directory'
    try:
        os.mkdir(folder_name)
        client = GithubClient()
        client.clone_repo(
            host='https://vcs.cnsga.aws.prod.au.internal.cba/CNS/cns-aws-onboarding-idam',
            branch='master',
            destination=folder_name
        )
        assert len(glob.glob(f'{folder_name}/*')) > 0
    finally:
        shutil.rmtree(folder_name, ignore_errors=False, onerror=None)

def test_is_github_internal_connectivity_works():
    """ Testing for internal github connectivity"""
    folder_name = 'test_clone_repo_directory'
    try:
        os.mkdir(folder_name)
        client = GithubClient()
        client.clone_repo(
            host='https://github.source.internal.cba/ApplicationInfrastructure/fde.engagement.portal',
            branch='master',
            destination=folder_name
        )
        assert len(glob.glob(f'{folder_name}/*')) > 0
    finally:
        shutil.rmtree(folder_name, ignore_errors=False, onerror=None)

def test_invalid_repo_throws_error():
    """ Testing for invalid repos"""
    folder_name = 'test_clone_repo_directory'
    try:
        os.mkdir(folder_name)
        client = GithubClient()
        with pytest.raises(ConnectivityException):
            client.clone_repo(
                host='https://vcs.cnsga.aws.prod.au.internal.cba/CNS/invalid-repo',
                branch='master',
                destination=folder_name
            )
    finally:
        shutil.rmtree(folder_name, ignore_errors=False, onerror=None)
