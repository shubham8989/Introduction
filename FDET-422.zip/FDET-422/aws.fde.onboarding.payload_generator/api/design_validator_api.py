""" Adding the API """
from flask import Flask
from payload_generator.services.design_validation_service import DesignValidationService
from payload_generator.services.payload_service import PayloadService

APP = Flask(__name__)

@APP.route('/design-validator/v1/validate/<ci_number>', methods=["GET", "POST"])
def payload(ci_number):
    """ Validates the design"""
    design_validator = DesignValidationService()
    request_id = design_validator.start_design_validation(ci_number)

    payload_service = PayloadService()
    return payload_service.start_payloads_generations(request_id)
