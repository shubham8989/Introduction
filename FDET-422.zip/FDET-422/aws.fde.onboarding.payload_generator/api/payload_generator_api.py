""" This module exposes an API on the payload generator"""
from flask import Flask, redirect
from payload_generator.services.payload_service import PayloadService
from payload_generator.services.healthcheck_service import HealthcheckService

APP = Flask(__name__)

@APP.route('/')
def default():
    """Redirect to healthcheck by default"""
    return redirect("/health", code=302)

@APP.route('/payload-generator/v1/payload/<request_id>', methods=["GET", "POST"])
def payload(request_id):
    """Generates the payloads"""
    payload_service = PayloadService()
    return payload_service.start_payloads_generations(request_id)

@APP.route('/health', methods=["GET"])
def health():
    """Healthcheck endpoint"""
    healthcheck_service = HealthcheckService()
    return healthcheck_service.check_health()
