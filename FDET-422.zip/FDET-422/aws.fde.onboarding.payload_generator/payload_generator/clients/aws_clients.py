""" Module to return s3 client or service object"""
import boto3
from payload_generator.commons.errors import OperationsException

def get_s3_client():
    """get s3 client"""
    client = boto3.resource('s3')
    return client

def get_s3_bucket(bucket_name):
    """get s3 s3 bucket object and return"""
    s3client = get_s3_client()
    if s3client.Bucket(bucket_name) in s3client.buckets.all():
        try:
            s3_bucket = s3client.Bucket(bucket_name)
        except Exception as exp:
            errors = f'Get S3 Bucket: Error - S3 Bucket [{bucket_name}] object'
            raise OperationsException(f'{exp}')
    else:
        errors = f'Get S3 Bucket: S3 Bucket [{bucket_name}] does not exists'
        raise OperationsException(f'{errors}')
    return s3_bucket
