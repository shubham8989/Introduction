"""This module does renaming and zipping of Idam files ."""

import glob
import datetime
import os
import zipfile
from shutil import copyfile
from shutil import rmtree
from payload_generator.commons.errors import OperationsException

class IdamFilesProcessor:
    """This Class defines Public function rename_idam_files."""

    def rename_compress_idamfiles(self, src_dir, zip_dir, ci_number, temp_dir=None):
        """This function will perform renaming and compression of idam_files"""
        try:
            if temp_dir is None:
                temp_dir = f'temp_{ci_number}'
            if not os.path.exists(temp_dir):
                os.mkdir(temp_dir)
            self._rename_idam_files(src_dir, temp_dir, ci_number)
            self._compress_idam_files(temp_dir, zip_dir, ci_number)
        except NotADirectoryError as exp:
            raise OperationsException(f'tempfolder creation failed [{ci_number}]', exp)
        except Exception as exp:
            raise OperationsException(f'tempfolder creation failed [{ci_number}]', exp)
        finally:
            rmtree(temp_dir)

    def _rename_idam_files(self, source_dir, dest_dir, ci_number):
        """This func used for renaming IDAM files."""
        try:
            files = glob.glob(f'{source_dir}/*.csv')
            if len(files) == 0:
                raise OperationsException('Invalid source directory or no csv files found')
            for abs_fname in files:
                try:
                    file_name = os.path.basename(abs_fname)
                    new_name = file_name.replace(ci_number[2:], '')
                    target_file = f'{dest_dir}/{new_name}'
                    copyfile(abs_fname, target_file)
                except FileNotFoundError as exp:
                    raise OperationsException(
                        f'Error: File not found [{abs_fname}] - [{ci_number}]',
                        exp
                    )
                except Exception as exp:
                    raise OperationsException(f'Error while copying file [{target_file}]', exp)
        except NotADirectoryError as exp:
            raise OperationsException(
                f'Error: Not able to Access to folder [{source_dir}] - [{ci_number}]',
                exp
            )
        except Exception as exp:
            raise OperationsException(
                f'Error while reading files from source directory [{source_dir}]',
                exp
            )

    def _compress_idam_files(self, src, dest, ci_number):
        """This func used for Zipping IDAM files."""
        current_date = datetime.datetime.today().strftime('%d-%b-%Y')
        try:
            output_zipfile = zipfile.ZipFile(f'{dest}/Idamfiles_{ci_number}_{current_date}.zip',\
                            'w', zipfile.ZIP_DEFLATED)
            rootdir = os.path.basename(src)
            for dirpath, dirnames, filenames in os.walk(src):
                for filename in filenames:
                    if filename.endswith(".csv"):
                        file_path = os.path.join(dirpath, filename)
                        parent_path = os.path.relpath(file_path, src)
                        output_zipfile.write(file_path, parent_path)
            output_zipfile.close()
        except NotADirectoryError as exp:
            raise OperationsException(
                f'tempfolder Zip creation failed invalid zip folder[{parent_path}] - [{ci_number}]',
                exp
            )
        except Exception as exp:
            raise OperationsException(f'Error creating the zip file in the directory [{dest}]', exp)
