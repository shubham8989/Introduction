""" API health and integration status """
import datetime

class HealthcheckService:
    """ This is the main HealthcheckService class"""

    """ TODO: Add checks for downstream services:
    both GHE instances and SMTP server """

    def check_health(self):
        """ Determine the health of the service """
        now = self._generate_timestamp()
        response = "Healthy as of: " + now
        return response

    @staticmethod
    def _generate_timestamp():
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return str(now)
