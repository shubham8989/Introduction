""" This module contains the design template validation services """
import json
import os
import shutil
from payload_generator.commons.logger import get_logger
from payload_generator.github.github_design_controller import GithubDesignController
from payload_generator.github.github_client import GithubClient
from payload_generator.validator.design_validator import DesignValidator
from payload_generator.commons.constants import DESIGN_DOCS_BASE_DIRECTORY
from config.config_factory import FetchConfig



class DesignValidationService:
    """ This is the main DesignValidationService class"""

    def __init__(self):
        super().__init__()
        self.logger = get_logger('DesignValidationService')
        github_client = GithubClient()
        self.github_design_controller = GithubDesignController(github_client)
        self.design_validator = DesignValidator()
        self.base_folder = os.getenv('DESIGN_DOCS_BASE_DIRECTORY', DESIGN_DOCS_BASE_DIRECTORY)

    def start_design_validation(self, ci_number):
        """ The main controller of the service """
        self.github_design_controller.start_process(ci_number, self.base_folder)
        metadata, ws_req, config = self._generate_validation_payloads(self.base_folder, ci_number)
        exchange = self.design_validator.start_validations(
            metadata,
            ws_req,
            ci_number,
            config
        )
        self.design_validator.analyze_exchange(exchange)
        self._post_validation_treatment(self.base_folder, ci_number)
        return self._get_request_id(self.base_folder, ci_number)

    @staticmethod
    def _post_validation_treatment(base_path, ci_number):
        if os.path.exists(f'{base_path}/{ci_number}/output'):
            shutil.rmtree(f'{base_path}/{ci_number}/output')
        shutil.copytree(
            f'{base_path}/{ci_number}/config/',
            f'{base_path}/{ci_number}/output'
        )

    @staticmethod
    def _generate_validation_payloads(base_path, ci_number):
        return (
            json.load(open(f'{base_path}/{ci_number}/config/metadata.json', 'r')),
            json.load(open(f'{base_path}/{ci_number}/config/workspace_requirements.json', 'r')),
            {
                'metadata_config' : FetchConfig.get_config('MetaDataConfig'),
                'ws_req_config' : FetchConfig.get_config('WsRequirementTemplate')
            }
        )

    @staticmethod
    def _get_request_id(base_folder, ci_number):
        """ Returns the request id """
        metadata = json.load(open(f'{base_folder}/{ci_number}/output/metadata.json', 'r'))
        return metadata.get('request').get('request_it_id')
