""" This module contains all the payload related services"""
import os
import json
import glob
import shutil
from datetime import datetime
from config.config_factory import FetchConfig
from payload_generator.commons.logger import get_logger
from payload_generator.commons.errors import (
    ConnectivityException,
    OperationsException,
    ValidationException,
    ServiceLimitException
)
from payload_generator.commons.constants import (
    VCS_BASE_DIRECTORY,
    IDAM_EMAIL_RECEIPIENT,
    DESIGN_DOCS_BASE_DIRECTORY
)
from payload_generator.commons.util import find_in_list, load_files_contents_dict
from payload_generator.github.github_payload_controller import GithubPayloadController
from payload_generator.github.github_client import GithubClient
from payload_generator.validator.payload_validator import PayloadValidator
from payload_generator.idam.idam_files_processor import IdamFilesProcessor
from payload_generator.workspace.workspace_payload_generator import WorkspacePayloadGenerator
from payload_generator.notification.email_controller import EmailController
from payload_generator.notification.smtp_controller import SMTPController
from payload_generator.ipam.ipam_payload_controller import IPAMPayloadController
from payload_generator.data_store.s3_manager import S3Controller

class PayloadService:
    """ This is the main PayloadService class"""

    def __init__(self):
        """ The constructor takes care of logging activation etc."""
        super().__init__()
        self.logger = get_logger('PayloadService')
        self.base_folder = os.getenv('VCS_BASE_DIRECTORY', VCS_BASE_DIRECTORY)
        github_client = GithubClient()
        self.github_controller = GithubPayloadController(github_client)
        self.validator = PayloadValidator()
        self.idam_processor = IdamFilesProcessor()
        self.workspace_payload_generator = WorkspacePayloadGenerator()
        self.email_controller = EmailController()
        self.smtp_controller = SMTPController()
        self.ipam_controller = IPAMPayloadController()
        self.s3_controller = S3Controller()

    def start_payloads_generations(self, request_number=None):
        """ The main controller of the service"""
        start_time = datetime.now()
        try:
            self._is_request_number_valid(request_number)
            self._create_base_folder_structure()
            ci_number = self._fetch_github_resources(request_number)
            self._run_validations(ci_number)
            self._create_output_folders(ci_number)
            self._generate_idam_payload(ci_number)
            self._generate_workspace_payload(ci_number)
            self._send_notifications(ci_number)
            self._generate_ipam_payload(ci_number)
            self._upload_artifacts_to_s3(ci_number)
            return self._generate_output(ci_number, start_time)
        except (
                ConnectivityException,
                OperationsException,
                ServiceLimitException,
                ValidationException
            ) as ob_exp:
            self.logger.error(ob_exp)
            error_msg = str(ob_exp)
            self._send_error_notification(error_msg)
            return self._generate_error_report(start_time, error_msg)
        except Exception as exp:
            self.logger.error(exp)
            error_msg = str(exp)
            self._send_error_notification(error_msg)
            return self._generate_error_report(start_time, error_msg)

    def _upload_artifacts_to_s3(self, ci_number):
        files = glob.glob(f'{self.base_folder}/{ci_number}/output/*')
        for file in files:
            self.s3_controller.move_to_s3(file, ci_number)

    def _generate_error_report(self, start_time, error_msg):
        output = {}
        output['meta'] = self._get_metadata(start_time)
        output['error'] = {}
        output['error']['message'] = error_msg
        return output

    def _create_output_folders(self, ci_number):
        """ Creates the folders to copy output"""
        temp_idam_folder = f'{self.base_folder}/{ci_number}/temp_idam'
        output_folder = f'{self.base_folder}/{ci_number}/output'
        if os.path.exists(temp_idam_folder):
            shutil.rmtree(temp_idam_folder)
        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)
        os.mkdir(temp_idam_folder)
        os.mkdir(output_folder)

    @staticmethod
    def _is_request_number_valid(request_number):
        if not request_number:
            raise OperationsException('Cannot proceed without a request number')
        if not request_number.startswith('REQ'):
            raise ValidationException(
                f'Invalid request number [{request_number}].',
                'Request numbers should start with [REQ]'
            )

    def _create_base_folder_structure(self):
        if not os.path.exists(self.base_folder):
            os.mkdir(self.base_folder)

    def _fetch_github_resources(self, request_number):
        self.logger.info(f'Fetching the github resources for [{request_number}]')
        ci_number = self.github_controller.start_process(
            request_number=request_number,
            base_path=self.base_folder
        )
        self.logger.info(
            f'Successfully fetched resources for github resources for [{request_number}]'
        )
        return ci_number

    def _run_validations(self, ci_number):
        workspace_payload, idam_contents = self._generate_validator_payload(ci_number)
        config = FetchConfig.get_config('WorkspaceParamDef')
        exchange = self.validator.start_validation(workspace_payload, idam_contents, config)
        self.validator.analyze_exchange(exchange)

    def _generate_idam_payload(self, ci_number):
        src_folder = f'{self.base_folder}/{ci_number}/idam/idam-vro-payload'
        temp_idam_folder = f'{self.base_folder}/{ci_number}/temp_idam'
        output_folder = f'{self.base_folder}/{ci_number}/output'
        self.idam_processor.rename_compress_idamfiles(
            src_folder,
            output_folder,
            ci_number,
            temp_idam_folder
        )

    def _generate_workspace_payload(self, ci_number):
        workspace_def_candidates = glob.glob(f'{self.base_folder}/{ci_number}/workspace/*.json')
        if len(workspace_def_candidates) == 0:
            raise OperationsException(f'Could not find a workspace definition file for {ci_number}')
        if len(workspace_def_candidates) > 1:
            raise ServiceLimitException(
                'Handling multiple workspace definition files is not supported yet.'
            )
        config = FetchConfig.get_config('WorkspaceParamDef')
        workspace_def_json = json.load(open(workspace_def_candidates[0], 'r'))
        self.workspace_payload_generator.process_workspace_payload(
            workspace_def_json,
            config,
            f'{self.base_folder}/{ci_number}/output/'
        )

    def _send_notifications(self, ci_number):
        email_data = self._extract_email_data(ci_number)
        self._send_notifications_to_idam(ci_number, email_data)
        self._send_notifications_to_users(ci_number, email_data)

    def _generate_ipam_payload(self, ci_number):
        """ Generates the IPAM Payload """
        design_dir = os.getenv('DESIGN_DOCS_BASE_DIRECTORY', DESIGN_DOCS_BASE_DIRECTORY)
        ws_req_file = f'{design_dir}/{ci_number}/output/workspace_requirements.json'
        if os.path.exists(design_dir) and os.path.exists(ws_req_file):
            destination = f'{self.base_folder}/{ci_number}/output'
            self.ipam_controller.generate_ipam_payload(ws_req_file, destination)

    def _extract_email_data(self, ci_number):
        email_data = {}
        workspace_pld_candidates = glob.glob(f'{self.base_folder}/{ci_number}/workspace/*.json')
        workspace_def = json.load(open(workspace_pld_candidates[0], 'rb'))
        custom_properties = workspace_def.get('CustomProperties')
        workspace_object = find_in_list(
            custom_properties,
            lambda x: x.get('WorkspaceName') is not None
        )
        requested_for_list = workspace_def.get('requested_for')
        requested_for_emails_list = list(map(lambda x: x['requestor_email'], requested_for_list))
        requested_by_list = workspace_def.get('requested_by')
        requested_by_emails_list = list(map(lambda x: x['requestor_email'], requested_by_list))
        email_data['workspace_name'] = workspace_object.get('WorkspaceName')
        email_data['email_to'] = requested_for_emails_list
        email_data['email_cc'] = requested_by_emails_list
        return email_data

    def _send_notifications_to_idam(self, ci_number, email_data):
        email_map = self.email_controller.construct_email(
            email_to=[IDAM_EMAIL_RECEIPIENT],
            email_cc=[],
            template_name='sent_to_team',
            template_config={
                'CI_NUMBER' : ci_number,
                'WORKSPACE_NAME': email_data.get('workspace_name'),
                'TEAM_NAME' : 'IDAM'
            }
        )
        self.smtp_controller.send_email(email_map.get('receivers'), email_map.get('message'))

    def _send_notifications_to_users(self, ci_number, email_data):
        email_map = self.email_controller.construct_email(
            email_to=email_data.get('email_to'),
            email_cc=email_data.get('email_cc'),
            template_name='sent_to_team',
            template_config={
                'CI_NUMBER' : ci_number,
                'WORKSPACE_NAME': email_data.get('workspace_name'),
                'TEAM_NAME' : 'IDAM'
            }
        )
        self.smtp_controller.send_email(email_map.get('receivers'), email_map.get('message'))

    def _send_error_notification(self, exp):
        pass

    def _generate_validator_payload(self, ci_number):
        source_folder = f'{self.base_folder}/{ci_number}'
        if not (
                os.path.exists(source_folder) and
                os.path.exists(f'{source_folder}/idam') and
                os.path.exists(f'{source_folder}/workspace')
        ):
            raise OperationsException(
                f'Could not find dependency folders required to process [{ci_number}]',
                'Necessary [{source_folder}], [{source_folder}/idam], ' +
                '[{source_folder}/workspace] and their contents'
            )
        ws_files_list = glob.glob(f'{source_folder}/workspace/*.json')
        if not ws_files_list or len(ws_files_list) < 1:
            raise OperationsException(f'Could not find a workspace metadata file for [{ci_number}]')
        numeric_ci = ci_number[:2]
        ws_file = find_in_list(ws_files_list, lambda x: numeric_ci in x)
        workspace_payload = json.load(open(ws_file, 'rb'))
        files = glob.glob(f'{source_folder}/idam/idam-vro-payload/*.csv')
        idam_contents = load_files_contents_dict(files)
        return workspace_payload, idam_contents

    def _generate_output(self, ci_number, start_time):
        """ Generates the output """
        output = {}
        output['meta'] = self._get_metadata(start_time)
        output['workspace_payload'] = self._read_workspace_output(ci_number)
        output['idam_payload'] = self._read_idam_output(ci_number)
        output['ipam_payload'] = self._read_ipam_output(ci_number)
        return output

    def _read_workspace_output(self, ci_number):
        ws_file = f'{self.base_folder}/{ci_number}/output/workspace_{ci_number[2:]}.json'
        return json.load(open(ws_file, 'rb'))

    def _read_idam_output(self, ci_number):
        return glob.glob(f'{self.base_folder}/{ci_number}/output/*.zip')[0]

    def _read_ipam_output(self, ci_number):
        ipam_file = f'{self.base_folder}/{ci_number}/output/ipam.json'
        return json.load(open(ipam_file, 'rb'))

    @staticmethod
    def _get_metadata(start_time):
        finished_time = datetime.now()
        metadata = {}
        metadata['start_time'] = start_time.strftime("%m/%d/%Y, %H:%M:%S")
        metadata['finished_time'] = finished_time.strftime("%m/%d/%Y, %H:%M:%S")
        metadata['elapsed_time'] = f'{(finished_time - start_time).total_seconds() * 1000} ms'
        return metadata
