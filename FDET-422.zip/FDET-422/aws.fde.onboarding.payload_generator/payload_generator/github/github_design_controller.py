""" This module contains the github management logic for the designs"""
from payload_generator.commons.constants import DESIGN_SPECIFICATIONS_REPO
from payload_generator.github.github_logic_controller import GithubLogicController

class GithubDesignController(GithubLogicController):
    """ This is the main implementation unit of this module """

    def __init__(self, github_client):
        """ Default constructor"""
        super().__init__()
        self.github_client = github_client

    def start_process(self, ci_number, base_directory):
        """ Start extracting design stuff """
        local_path = f'{base_directory}/{ci_number}'
        self.create_base_storage_structure(base_directory, local_path)
        self.github_client.clone_repo(
            host=DESIGN_SPECIFICATIONS_REPO,
            branch=ci_number,
            destination=local_path
        )
