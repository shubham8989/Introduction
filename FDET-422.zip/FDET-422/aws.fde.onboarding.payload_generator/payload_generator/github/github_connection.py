# pylint: disable=R0201,R1710,W0613,E0401,R0903
"This module is for github connection and fetching the files from branch"
from github import Github
from payload_generator.commons.errors import (
    ConnectivityException,
    ValidationException,
    OperationsException
)

class GitHubController:
    "github controller class"
    def __init__(self, base_url, token, repository_name):
        self.base_url = base_url
        self.token = token
        self.repository_name = repository_name
        self.git_repo = self._github_connector(self.base_url, self.token, self.repository_name)

    def fetch_files_from_branch(self, branch_name, fetch_content=None):
        "method for fetching the files from the branch"
        repo = self.git_repo
        sha = self._get_sha_for_commit_id(repo, branch_name)
        contents = self._fetch_contents(sha, "")
        file_list = {}
        content_list = self._get_dictionary_of_file(contents, file_list, sha)
        if fetch_content:
            file_list = self._compare_element(content_list, fetch_content)
        else:
            file_list = content_list
        return file_list

    def _github_connector(self, base_url, token, repository_name):
        "method to connect github"
        try:
            git_conn = Github(base_url=base_url, login_or_token=token, verify=False)
            repo = git_conn.get_repo(repository_name)
            return repo
        except Exception as exc:
            raise ConnectivityException("GitHub connection is refused", exc)

    def _get_dictionary_of_file(self, contents, file_list, sha):
        "method for returning dictionary object of all file contents"
        file_list = {}
        for content in contents:
            if content.type == "dir":
                dir_contents = self._fetch_contents(sha, content.path)
                file_list[content.name] = self._get_dictionary_of_file(dir_contents, file_list, sha)
            elif content.type == "file":
                file_list[content.name] = content.decoded_content.decode('utf-8')
            else:
                raise OperationsException(f'Unknown content type to decode [{content.type}]')
        return file_list

    def _get_sha_for_commit_id(self, repository, branch_name):
        "Method to fetch the branch with latest commit id"
        branch = repository.get_branches()
        matched_branch = list(filter(lambda match: match.name == branch_name, branch))
        if matched_branch:
            return matched_branch[0].commit.sha
        if not matched_branch:
            raise ValidationException('commit id or Branch exists with that name')

    def _fetch_contents(self, sha, path):
        "methods for fecthing the content"
        contents = self.git_repo.get_contents(path=path, ref=sha)
        return contents

    def _compare_element(self, input_json, match_name):
        """ function to comapare input file with contents """
        file_list = {}
        for in_key, in_val in input_json.items():
            if in_val and isinstance(in_val, bytes):
                if in_key == match_name:
                    file_list[in_key] = in_val

            elif isinstance(in_val, dict):
                if in_key == match_name:
                    return_list = in_val
                else:
                    return_list = self._compare_element(in_val, match_name)
                if len(return_list) > 0:
                    file_list[in_key] = return_list

            elif in_val and isinstance(in_val, list):
                if in_key == match_name:
                    return_list = in_val
                else:
                    return_list = self._compare_element(in_val, match_name)
                if len(return_list) > 0:
                    file_list[in_key].append(return_list)
        return file_list
