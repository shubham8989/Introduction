""" Github common functions """
import os
import shutil
from payload_generator.commons.errors import OperationsException

class GithubLogicController:
    """ Github Controller """

    def create_base_storage_structure(self, base_directory, local_path):
        """ Creates temp folders before start processing """
        try:
            if not os.path.exists(base_directory):
                os.mkdir(base_directory)
            if os.path.exists(local_path):
                shutil.rmtree(local_path, ignore_errors=False, onerror=None)
            os.mkdir(local_path)
        except Exception as exp:
            raise OperationsException(f'Error creating the files structure [{local_path}]', exp)
