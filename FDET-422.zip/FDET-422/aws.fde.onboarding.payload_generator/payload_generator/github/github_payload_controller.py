"""
This module represents the implementation of the git management,
logic for payload module generation
"""

import os
import glob
import json
import shutil
from payload_generator.commons.errors import (
    ValidationException,
    OperationsException,
    ServiceLimitException
)
from payload_generator.commons.constants import (
    CNS_AWS_ONBOARDING_IDAM_REPO,
    CNS_AWS_ONBOARDING_REPO,
    WORKSPACE_DEF_FILENAME_PATTERN
)
from payload_generator.commons.util import extract_cinumber_from_workspace_def
from payload_generator.github.github_logic_controller import GithubLogicController

class GithubPayloadController(GithubLogicController):
    """ GithubPayloadController contains the logic for managing the flow """

    def __init__(self, github_client):
        """ Default constructor"""
        super().__init__()
        self.github_client = github_client

    def start_process(self, request_number, base_path):
        """ The main public controller """
        vcs_local_path = f'{base_path}/{request_number}'
        self.create_base_storage_structure(base_path, vcs_local_path)
        self.github_client.clone_repo(
            host=CNS_AWS_ONBOARDING_REPO,
            branch=request_number,
            destination=vcs_local_path
        )
        ci_number = self._find_ci_number_from_repo(vcs_local_path)
        idam_local_path = f'{base_path}/{ci_number}'
        self.create_base_storage_structure(base_path, idam_local_path)
        self._prepare_op_folder_structure(idam_local_path, vcs_local_path)
        self.github_client.clone_repo(
            host=CNS_AWS_ONBOARDING_IDAM_REPO,
            branch=ci_number,
            destination=f'{idam_local_path}/idam'
        )
        return ci_number

    def _prepare_op_folder_structure(self, base_folder, vcs_folder):
        """ Creates the file structure that the files will be stored in """
        try:
            files_in_base = glob.glob('base_folder')
            if files_in_base and len(files_in_base) > 0:
                for file_name in files_in_base:
                    shutil.rmtree(file_name, ignore_errors=False, onerror=None)
            os.mkdir(f'{base_folder}/idam')
            shutil.copytree(vcs_folder, f'{base_folder}/workspace')
        except Exception as exp:
            error_msg = f'Error performing the op folder structure creation and copying.' \
                f' From [{vcs_folder}] to [{base_folder}]'
            raise OperationsException(error_msg, exp)

    def _find_ci_number_from_repo(self, local_path):
        """ Fetch the CI number """
        files_list = glob.glob(f'{local_path}/*')
        folder_prefix = f'{local_path}/'
        workspace_payload_candidates = [file_name for file_name in files_list if file_name[file_name.index(folder_prefix) + len(folder_prefix):].startswith(WORKSPACE_DEF_FILENAME_PATTERN)]
        if len(workspace_payload_candidates) > 1:
            error_msg = 'Handling multiple workspace creation requests in the same request is not handled yet.'
            raise ServiceLimitException(error_msg, 'Please contact your service admin for more details')
        if len(workspace_payload_candidates) == 0:
            raise ValidationException('Could not find any workspace definition files')
        workspace_definition_json = json.load(open(workspace_payload_candidates[0], 'rb'))
        return extract_cinumber_from_workspace_def(workspace_definition_json)
