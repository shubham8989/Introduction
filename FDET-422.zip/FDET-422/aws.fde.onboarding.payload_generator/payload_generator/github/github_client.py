""" This is the github management clinet """
from git import Repo, GitCommandError
from payload_generator.commons.errors import ConnectivityException

class GithubClient:
    """ This class implements the github client"""

    def clone_repo(self, host, branch, destination):
        """ Clones a given branch in a repo to a given destination"""
        try:
            repo = Repo.clone_from(
                url=host,
                to_path=destination,
                branch=branch,
                depth=1
            )
        except GitCommandError as exp:
            error_msg = f'Error connecting to github - [{host}] and branch [{branch}]'
            raise ConnectivityException(error_msg, exp)
            