"""
Classes to handle errors
"""

class OnboardingBaseException(Exception):
    """ The base exception used for onboarding """

class ConnectivityException(OnboardingBaseException):
    """ Exception class  for connectivity"""
    def __init__(self, message, exception=None):
        super().__init__(f'ConnectivityException :: {message}\n More Details :: {exception}')

class OperationsException(OnboardingBaseException):
    """ excepton class for operations """
    def __init__(self, message, exception=None):
        super().__init__(f'OperationsException :: {message}\n More Details :: {exception}')

class ServiceLimitException(OnboardingBaseException):
    """ Exception class for service limit"""
    def __init__(self, message, exception=None):
        super().__init__(f'ServiceLimitException :: {message}\n More Details :: {exception}')

class ValidationException(OnboardingBaseException):
    """ exception class for onbaording base exception"""
    def __init__(self, message, exception=None):
        super().__init__(f'ValidationException :: {message}\n More Details :: {exception}')
