"This module is for Extracting ci number"
import codecs
from payload_generator.commons.errors import ValidationException

def find_in_list(list, filter):
    "find an item in list based on the filter function provided"
    for data in list:
        if filter(data):
            return data
    return None

def read_json_file(file_location, encoding='base64'):
    "Reading json files"
    content = ''
    with codecs.open(file_location, encoding=encoding) as file:
        for line in file:
            content = f'{content}\n{line}'
    return content

def extract_cinumber_from_workspace_def(workspace_def):
    "extracting cinumber from the workspace defination"
    custom_properties = workspace_def.get('CustomProperties')
    if custom_properties is None:
        raise ValidationException(
            f'Custom properties in the workspace definition cannot be empty',
            workspace_def
        )
    ci_number_object = find_in_list(custom_properties, lambda x: x.get('CINumber') is not None)
    if ci_number_object is None:
        raise ValidationException(
            f'The ci number cannot be empty in given workspace payload',
            workspace_def
        )
    return ci_number_object.get('CINumber')

def load_files_contents_dict(files_list):
    """ Load IDAM content from files """
    idam_content = {}
    for file_name in files_list:
        file = open(file_name, 'r')
        file_contents = file.read()
        idam_content[file_name] = file_contents
    return idam_content
