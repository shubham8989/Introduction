""""This module reads vRO json ,extracts relevent tags and creates new workspace json file"""
import json
import os
from payload_generator.commons.errors import (
    OperationsException,
    ValidationException
)
from payload_generator.commons.util import find_in_list, extract_cinumber_from_workspace_def
from payload_generator.commons.constants import DOMAIN_WORKSPACE_EMAIL
from payload_generator.commons.logger import get_logger

class WorkspacePayloadGenerator:
    """class to define the functions to load , process and create new valid workspace paylod"""

    def __init__(self):
        super().__init__()
        self.logger = get_logger('WorkspacePayloadGenerator')

    def process_workspace_payload(self, workspace_def, config, destination):
        """ function process workspace payload creation as mentioned in config"""
        self.logger.info("Starting Workspace Payload creation")
        ws_name = self._extract_workspace_name(workspace_def)
        ws_email = f'{ws_name}@{DOMAIN_WORKSPACE_EMAIL}'
        output = {}
        output_json = self._extract_elements(workspace_def, config, output)
        output_json['workspace_email'] = ws_email
        ci_number = extract_cinumber_from_workspace_def(workspace_def)
        ci_number = ci_number[2:]
        json_data_str = json.dumps(output_json, indent=4)
        target_json_filename = f'workspace_{ci_number}.json'
        output_file_loc = os.path.join(destination, target_json_filename)
        try:
            with open(output_file_loc, 'w') as outfile:
                outfile.write(json_data_str)
        except Exception as exp:
            errors = f'Error while creating the file [{target_json_filename}]'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'Error creating the file [{target_json_filename}]', exp)
        self.logger.info("Workspace Payload creation ends")

    def _extract_workspace_name(self, workspace_def):
        """This function returs specific set of json key value pair from workspace json obj"""
        custom_properties = workspace_def.get('CustomProperties')
        if custom_properties is None:
            errors = 'Custom properties in the workspace definition cannot be empty'
            self.logger.error(f'Found errors :: {errors}')
            raise ValidationException(
                'Custom properties in the workspace definition cannot be empty'
            )
        ws_name_object = find_in_list(
            custom_properties,
            lambda x: x.get('WorkspaceName') is not None)
        if ws_name_object is None:
            errors = f'{ws_name_object} in the workspace definition cannot be empty'
            self.logger.error(f'Found errors :: {errors}')
            raise ValidationException(f'The WorkspaceName cannot be empty')
        return ws_name_object.get('WorkspaceName')

    def _extract_elements(self, workspace_def, config, output):
        """ function to identify mandatory elements from config and extract from ws payload """
        output = {}
        for config_key, config_val in config.items():
            if isinstance(config_val, bool):
                if config_val and workspace_def.get(config_key) is not None:
                    output[config_key] = workspace_def.get(config_key)
                elif config_val and workspace_def.get(config_key) is None:
                    errors = f'The {config_key} cannot be empty in workspace payload'
                    self.logger.error(f'Found errors :: {errors}')
                    raise ValidationException(
                        f'The {config_key} cannot be empty in workspace payload'
                        )
            elif isinstance(config_val, dict):
                ws_object = workspace_def.get(config_key)
                if ws_object:
                    output[config_key] = self._extract_elements(ws_object, config_val, output)
            elif isinstance(config_val, list):
                elements = workspace_def.get(config_key)
                if elements and len(elements) > 0:
                    resolve_array = []
                    for element in elements:
                        if len(config_val) > 0:
                            for config_elements in config_val:
                                returned = self._extract_elements(
                                    element,
                                    config_elements,
                                    output
                                    )
                                if len(returned) != 0:
                                    resolve_array.append(returned)
                        else:
                            returned = self._extract_elements(element, config_val[0], output)
                            resolve_array.append(returned)
                    if len(resolve_array) != 0:
                        output[config_key] = resolve_array
                else:
                    errors = f'The {config_key} not found in workspace payload'
                    self.logger.error(f'Found errors :: {errors}')
                    raise ValidationException(
                        f'The {config_key} cannot be empty in workspace payload'
                        )
        return output

    def load_json(self, file_name):
        """Function to load workspace payload from directory specified and return worspace object"""
        workspace_definition_json = json.load(open(file_name, 'rb'))
        if workspace_definition_json is None:
            errors = f'Given json is empty {file_name}'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'Given json is empty {file_name}')
        return workspace_definition_json
