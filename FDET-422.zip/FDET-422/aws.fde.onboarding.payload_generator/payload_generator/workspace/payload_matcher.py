"""This module reads vRO json ,extracts relevent tags and creates new workspace json file"""

class WorkspacePayloadComparator:
    """class to define the functions to load , process and create new valid workspace paylaod"""

    def compare_payloads(self, workspace_def, output_json, exchange):
        """ function compare input payload and output payload"""
        self.compare_elements(workspace_def, output_json, exchange)

    def compare_elements(self, workspace_def, out_json, exchange, depth=None):
        """ function to identify mandatory elements from config and extract from ws payload """
        if depth is None:
            depth = ['root']
        for out_key, out_val in out_json.items():
            if isinstance(out_val, str):
                if out_val and workspace_def.get(out_key) is None:
                    msg = {self._format_depth(depth, out_key)}
                    exchange['errors'].append(
                        f'Value for {msg} not found in the output definition'
                    )
                elif out_val != workspace_def.get(out_key):
                    msg = {self._format_depth(depth, out_key)}
                    exchange['errors'].append(
                        f'Value mismatch {msg} in the output definition'
                    )
            elif isinstance(out_val, dict):
                ws_object = workspace_def.get(out_key)
                if out_val == ws_object:
                    pass
                elif ws_object and ws_object != out_val:
                    depth.append(out_key)
                    self.compare_elements(ws_object, out_val, exchange, depth)
                    depth = ['root']
            elif isinstance(out_val, list):
                elements = workspace_def.get(out_key)
                if out_val == elements:
                    pass
                elif out_val and len(out_val) > 0:
                    depth.append(out_key)
                    counter = 0
                    for item in out_val:
                        depth.append(f'[{counter}]')
                        if len(out_val) > 0:
                            self.compare_elements(
                                elements[counter],
                                item,
                                exchange,
                                depth
                                )
                        else:
                            self.compare_elements(elements, out_val[0], exchange, depth)
                        depth.remove(f'[{counter}]')
                        counter += 1
                    depth = ['root']


    def _format_depth(self, depth, config_key):
        """ Formats the output for the depth """
        output = ' -> '.join(depth)
        return f'[{output} -> {config_key}]'
