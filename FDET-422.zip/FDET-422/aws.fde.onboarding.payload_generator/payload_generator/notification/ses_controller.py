from string import Template
import json
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import boto3
import os
import sys
sys.path.append('C:\\Users\\jains16\\Documents\\sprint3\\FDET-422\\aws.fde.onboarding.payload_generator')
os.environ["http_proxy"]= "http://config.au.eds.com/cba.pac"
os.environ["https_proxy"]= "http://config.au.eds.com/cba.pac"
from payload_generator.commons.errors import OperationsException
from payload_generator.commons.constants import EMAIL_SENDER
from payload_generator.commons.logger import get_logger
TEMPLATE = 'sent_to_team'
ATTACHMENT_1 = ['resources/test.txt']
ATTACHMENT_3 = ['resources/test.jpg']
PAYLOAD_1 = {
    'CI_NUMBER' : '123456789',
    'WORKSPACE_NAME' :  'TEST',
    'TEAM_NAME' : 'Testing'
}
client = boto3.client(
    'ses',
    aws_access_key_id= 'AKIAUGOUCMFE34HJDHWV',
    aws_secret_access_key= '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'
)

class EmailController:
    """ Handle creation of email content and address list """
    def __init__(self):
        super().__init__()
        self.logger = get_logger("EmailController")
    
    @staticmethod
    def _extract_template_json(template_name):
        template_location = 'resources/email_templates/' + template_name + '.json'
        with open(template_location, 'r') as file:
            contents = file.read()
        return json.loads(contents)

    def _attach_files_to_mail(self, attachments, msg):
        """ Methods to attach files in email"""
        """ TODO: should add attachment count validation using template """
        try:
            if type(attachments) is not list:
                raise OperationsException('Expected attachments as list')
            for attachment in attachments:
                if not os.path.exists(attachment):
                    self.logger.error(f'The path to the attachment  {attachment} cannot be found')
                    raise OperationsException(f'The path to the attachment \
                         {attachment} cannot be found')
                file_name = os.path.basename(attachment)
                file_size = os.path.getsize(attachment)/(1024*1024)
                if file_size > 1:
                    self.logger.error(f'The attached file {file_name} : \
                        exceeded more than 1MB', 'Please attach appropriate \
                        file size , less than 1MB')
                    raise OperationsException(f'The attached file {file_name} :\
                        exceeded more than 1MB', 'Please attach appropriate \
                        file size , less than 1MB')
                ctype, encoding = mimetypes.guess_type(attachment)
                if ctype is None or encoding is not None:
                    ctype = 'application/octet-stream'
                with open(attachment, 'rb') as content_file:
                    content = content_file.read()
                    if content:
                        maintype, subtype = ctype.split('/', 1)
                        msg.add_attachment(content, maintype=maintype, subtype=subtype, \
                            filename=file_name)
                        self.logger.info(f'The attachment {file_name} is attached\
                            to the email object')
            return msg
        except Exception as exp:
            self.logger.error(f'Exception happened {exp}')
            raise exp


    def construct_email(self, email_sender, email_to, email_cc, template_name, template_config, attachments=None):
        """ TODO: Refactor to reduce parameter count """
        """ Construct an email message and receivers list from a given payload """
        template = self._extract_template_json(template_name)

        subject_template = Template(template.get('subject'))
        body_template = Template(template.get('body'))

        email_subject = subject_template.substitute(**template_config)
        email_body = body_template.substitute(**template_config)
        message = MIMEMultipart()
        part = MIMEText(email_body, 'html')
        message.attach(part)
        response = client.send_email(
            Destination={
                 'ToAddresses': [email_to]

            },
            Message={
                'Body': {
                    'Text': {
                        'Charset': 'UTF-8',
                        'Data': email_body ,
                    },
                },
                'Subject': {
                    'Charset': 'UTF-8',
                    'Data': email_subject
                }
            }
            ,
            Source= email_sender
        )


controller = EmailController()

email_1 = controller.construct_email(
        'Shubham.Jain@cba.com.au', 'Shubham.Jain@cba.com.au', 'Shubham.Jain@cba.com.au', TEMPLATE, PAYLOAD_1
    )



 