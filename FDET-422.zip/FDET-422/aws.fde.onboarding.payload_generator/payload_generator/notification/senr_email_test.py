from string import Template
import json
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import boto3
import os
import sys
sys.path.append('C:\\Users\\jains16\\Documents\\sprint3\\FDET-422\\aws.fde.onboarding.payload_generator')
os.environ["http_proxy"]= "http://config.au.eds.com/cba.pac"
os.environ["https_proxy"]= "http://config.au.eds.com/cba.pac"
from payload_generator.commons.errors import OperationsException
from payload_generator.commons.constants import EMAIL_SENDER
from payload_generator.commons.logger import get_logger
TEMPLATE = 'sent_to_team'
ATTACHMENT_1 = ['resources/test.txt']
ATTACHMENT_3 = ['resources/test.jpg']
PAYLOAD_1 = {
    'CI_NUMBER' : '123456789',
    'WORKSPACE_NAME' :  'TEST',
    'TEAM_NAME' : 'Testing'
}
client = boto3.client(
    'ses',
    aws_access_key_id= 'AKIAUGOUCMFE34HJDHWV',
    aws_secret_access_key= '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'
)

class EmailController:
    """ Handle creation of email content and address list """
    def __init__(self):
        super().__init__()
        self.logger = get_logger("EmailController")
    
    @staticmethod
    def _extract_template_json(template_name):
        template_location = 'resources/email_templates/' + template_name + '.json'
        with open(template_location, 'r') as file:
            contents = file.read()
        return json.loads(contents)

    def construct_email(self, email_sender, email_to, email_cc, template_name, template_config):
        """ TODO: Refactor to reduce parameter count """
        """ Construct an email message and receivers list from a given payload """
        template = self._extract_template_json(template_name)
        message = MIMEMultipart()
        subject_template = Template(template.get('subject'))
        body_template = Template(template.get('body'))

        email_subject = subject_template.substitute(**template_config)
        email_body = body_template.substitute(**template_config)
        # message body
        part = MIMEText(email_body, 'html')
        message.attach(part)
        # attachment
        part = MIMEApplication(open('resources/config/design_metadata_template.json', 'rb').read())
        part.add_header('Content-Disposition', 'attachment', filename='design_metadata_template.json')
        msg= [message.attach(part)]
        for r in msg:
            print(r)

controller = EmailController()

email_1 = controller.construct_email(
        'Shubham.Jain@cba.com.au', 'Shubham.Jain@cba.com.au', 'Shubham.Jain@cba.com.au', TEMPLATE, PAYLOAD_1
    )


