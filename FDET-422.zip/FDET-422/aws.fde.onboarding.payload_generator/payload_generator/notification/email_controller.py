""" This module construct email by creating template, attach files and address list """
from string import Template
import json
import os
from email.message import EmailMessage
import mimetypes
from payload_generator.commons.errors import OperationsException
from payload_generator.commons.constants import EMAIL_SENDER
from payload_generator.commons.logger import get_logger

class EmailController:
    """ Handle creation of email content and address list """
    def __init__(self):
        super().__init__()
        self.logger = get_logger("EmailController")

    @staticmethod
    def _extract_template_json(template_name):
        template_location = 'resources/email_templates/' + template_name + '.json'
        with open(template_location, 'r') as file:
            contents = file.read()
            return json.loads(contents)

    @staticmethod
    def _build_receivers(email_to, email_cc):
        return email_to + email_cc

    def _attach_files_to_mail(self, attachments, msg):
        """ Methods to attach files in email"""
        """ TODO: should add attachment count validation using template """
        try:
            if type(attachments) is not list:
                raise OperationsException('Expected attachments as list')
            for attachment in attachments:
                if not os.path.exists(attachment):
                    self.logger.error(f'The path to the attachment  {attachment} cannot be found')
                    raise OperationsException(f'The path to the attachment \
                         {attachment} cannot be found')
                file_name = os.path.basename(attachment)
                file_size = os.path.getsize(attachment)/(1024*1024)
                if file_size > 1:
                    self.logger.error(f'The attached file {file_name} : \
                        exceeded more than 1MB', 'Please attach appropriate \
                        file size , less than 1MB')
                    raise OperationsException(f'The attached file {file_name} :\
                        exceeded more than 1MB', 'Please attach appropriate \
                        file size , less than 1MB')
                ctype, encoding = mimetypes.guess_type(attachment)
                if ctype is None or encoding is not None:
                    ctype = 'application/octet-stream'
                with open(attachment, 'rb') as content_file:
                    content = content_file.read()
                    if content:
                        maintype, subtype = ctype.split('/', 1)
                        msg.add_attachment(content, maintype=maintype, subtype=subtype, \
                            filename=file_name)
                        self.logger.info(f'The attachment {file_name} is attached\
                            to the email object')
            return msg
        except Exception as exp:
            self.logger.error(f'Exception happened {exp}')
            raise exp

    def construct_email(self, email_to, email_cc, template_name, template_config, attachments=None):
        """ TODO: Refactor to reduce parameter count """
        """ Construct an email message and receivers list from a given payload """
        template = self._extract_template_json(template_name)

        subject_template = Template(template.get('subject'))
        body_template = Template(template.get('body'))

        email_subject = subject_template.substitute(**template_config)
        email_body = body_template.substitute(**template_config)

        msg = EmailMessage()
        msg.set_content(email_body)
        msg['Subject'] = email_subject
        msg['From'] = EMAIL_SENDER
        msg['To'] = ', '.join(email_to)
        msg['Cc'] = ', '.join(email_cc)

        receivers = self._build_receivers(email_to, email_cc)

        if attachments:
            msg = self._attach_files_to_mail(attachments, msg)
        return {
            'message' : msg,
            'receivers' :  receivers
        }
