from string import Template
import json
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
import boto3
import os
import sys
sys.path.append('C:\\Users\\jains16\\Documents\\sprint3\\FDET-422\\aws.fde.onboarding.payload_generator')
os.environ["http_proxy"]= "http://config.au.eds.com/cba.pac"
os.environ["https_proxy"]= "http://config.au.eds.com/cba.pac"

TEMPLATE = 'sent_to_team'
ATTACHMENT_1 = ['resources/test.txt']
ATTACHMENT_3 = ['resources/test.jpg']
PAYLOAD_1 = {
    'CI_NUMBER' : '123456789',
    'WORKSPACE_NAME' :  'TEST',
    'TEAM_NAME' : 'Testing'
}
client = boto3.client(
    'ses',
    aws_access_key_id= 'AKIAUGOUCMFE34HJDHWV',
    aws_secret_access_key= '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'
)


message = MIMEMultipart()
message['Subject'] = 'email subject string'
message['From'] = 'Shubham.Jain@cba.com.au'
message['To'] = ', '.join(['Shubham.Jain@cba.com.au'])
# message body
part = MIMEText('email body string', 'html')
message.attach(part)
# attachment

part = MIMEApplication(open('resources/config/design_metadata_template.json', 'rb').read())
part.add_header('Content-Disposition', 'attachment', filename='design_metadata_template.json')


message.attach(part)
response = client.send_raw_email(
    Source=message['From'],
    Destinations=['Shubham.Jain@cba.com.au'],
    RawMessage={
        'Data': message.as_string()
    }
)