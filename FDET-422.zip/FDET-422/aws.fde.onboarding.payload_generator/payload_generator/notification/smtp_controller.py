""" SMTP modules"""
import os
import smtplib
import ssl
from payload_generator.commons.constants import (
    EMAIL_SENDER,
    SMTP_HOST,
    SMTP_PORT
)
from payload_generator.commons.logger import get_logger
from payload_generator.commons.errors import ConnectivityException

class SMTPController:
    """ Authenticated messages over SMTP via CBA mail relay """
    """ TODO : Error handling """
    """ TODO : Handle missing environment variables """
    def __init__(self):
        credentials = self._retrieve_service_account_credentials()
        self.smtp_user = credentials.get('user')
        self.smtp_password = credentials.get('password')
        super().__init__()
        self.logger = get_logger("SMTPController")


    @staticmethod
    def _retrieve_service_account_credentials():
        """ Pull service account credentials from environment variables """
        return {
            'user' : os.environ.get('SMTP_USER') or 'username',
            'password' :  os.environ.get('SMTP_PASSWORD') or 'password'
        }

    # CRITICAL 50 , ERROR 40, WARNING 30 INFO 20 DEBUG 10  NOTSET 0
    def send_email(self, receivers, message):
        """ Send a given message over SMTP """
        self.logger.info("Starting Send Email")
        try:
            with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
                # Logger levels CRITICAL 50 , ERROR 40, WARNING 30 INFO 20 DEBUG 10  NOTSET 0
                log_debug_level = self.logger.getEffectiveLevel()
                if log_debug_level > 0:
                    server.set_debuglevel(2)
                """ TODO : Use correct TLS for security """
                server.starttls(context=ssl._create_unverified_context())
                # server.starttls(context=ssl.create_default_context())
                try:
                    server.login(self.smtp_user, self.smtp_password)
                except smtplib.SMTPAuthenticationError as exp:
                    error_msg = f'AuthenticationError to server [{SMTP_HOST}] and port[{SMTP_PORT}]'
                    self.logger.error(f'Send Email - Unsuccessfull {error_msg}')
                    raise ConnectivityException(error_msg, exp)
                server.sendmail(EMAIL_SENDER, receivers, message)
                self.logger.info("Send Email Successfully")
        except smtplib.SMTPConnectError as exp:
            error_msg = f'Error connecting to email server - [{SMTP_HOST}] and port [{SMTP_PORT}]'
            self.logger.error(f'Send Email - Unsuccessfull {error_msg}')
            raise ConnectivityException(error_msg, exp)
        except Exception as exp:
            self.logger.error(f'Send Email - Unsuccessfull {exp}')
            raise exp
