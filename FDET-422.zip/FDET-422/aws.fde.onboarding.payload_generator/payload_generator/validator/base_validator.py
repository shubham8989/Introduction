""" The common ABS for validation """
from abc import ABC
from payload_generator.commons.logger import get_logger
from payload_generator.commons.errors import ValidationException

class BaseValidator(ABC):
    """Base validations """

    def __init__(self):
        super().__init__()
        self.logger = get_logger("DesignValidator")

    def analyze_exchange(self, exchange):
        """ TODO: Send out notifications if there are errors """
        if len(exchange['errors']) > 0:
            errors = exchange['errors']
            self.logger.error(f'Found errors :: {errors}')
            raise ValidationException(f'Found errors :: {errors}')

    def _compare_attributes(self, incoming, config, exchange, depth=None):
        """ Compares two given JSON streams """
        if depth is None:
            depth = ['root']
        for config_key, config_val in config.items():
            if isinstance(config_val, bool):
                if config_val and incoming.get(config_key) is None:
                    msg = {self._format_depth(depth, config_key)}
                    exchange['errors'].append(
                        f'Could not find the mandatory field {msg} in the workspace definition'
                    )
            elif isinstance(config_val, dict):
                ws_object = incoming.get(config_key)
                if ws_object:
                    depth.append(config_key)
                    self._compare_attributes(ws_object, config_val, exchange, depth)
                    depth = ['root']
                else:
                    msg = self._format_depth(depth, config_key)
                    exchange['errors'].append(
                        f'Could not find the mandatory object {msg} in the workspace definition'
                    )
            elif isinstance(config_val, list):
                elements = incoming.get(config_key)
                if elements and len(elements) > 0:
                    depth.append(config_key)
                    counter = 0
                    for element in elements:
                        depth.append(f'[{counter}]')
                        self._compare_attributes(element, config_val[0], exchange, depth)
                        depth.remove(f'[{counter}]')
                        counter += 1
                    depth = ['root']
                else:
                    msg = self._format_depth(depth, config_key)
                    exchange['errors'].append(
                        f'Could not find the mandatory list {msg} in the workspace definition'
                    )

    def _format_depth(self, depth, config_key):
        """ Formats the output for the depth """
        output = ' -> '.join(depth)
        return f'[{output} -> {config_key}]'

    def _load_base_exchange(self, ci_number):
        """ Method to create a single dictionary of data called validation exchange"""
        exchange = {}
        exchange['errors'] = []
        exchange['logs'] = []
        exchange['metadata'] = {
            'ci-number': ci_number
        }
        return exchange
