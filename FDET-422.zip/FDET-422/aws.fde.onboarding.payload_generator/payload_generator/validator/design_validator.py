""" Design Validation Module """
from payload_generator.commons.logger import get_logger
from payload_generator.validator.base_validator import BaseValidator

class DesignValidator(BaseValidator):
    """ Implementation of the Design level validations """

    def __init__(self):
        super().__init__()
        self.logger = get_logger("DesignValidator")

    def start_validations(self, metadata_json, ws_requirements_json, ci_number, config):
        """ Go through the validation methods """
        exchange = self._load_exchange(metadata_json, ws_requirements_json, ci_number, config)
        self._validate_mandatory_parameters_exist(exchange)
        self._validate_cidr_size_requirements(exchange)
        self._validate_minimum_secure_size_requirements(exchange)
        return exchange

    def _validate_mandatory_parameters_exist(self, exchange):
        """ Validates whether all mandatory parameters exist """
        self._compare_attributes(
            exchange['inputs']['metadata'],
            exchange['config']['metadata'],
            exchange
        )
        self._compare_attributes(
            exchange['inputs']['ws_req'],
            exchange['config']['ws_req'],
            exchange
        )

    def _validate_cidr_size_requirements(self, exchange):
        """ Validate the CIDR size conditions """
        zone_req = exchange.get('inputs').get('ws_req').get('zone_cidr_sizes')
        for zone_name, cidr in zone_req.items():
            if not cidr.startswith('/'):
                exchange['errors'].append(
                    f'Invalid CIDR definition [{cidr}] for [{zone_name}]'
                )
            else:
                cidr_size = int(cidr[1:])
                if cidr_size != 0 and cidr_size > 28:
                    exchange['errors'].append(
                        f'Invalid CIDR Size [{cidr}] for [{zone_name}]'
                    )

    def _validate_minimum_secure_size_requirements(self, exchange):
        """ The minimum secure size requirements """
        ws_components = exchange.get('inputs').get('metadata').get('workspace')
        db_components = ws_components.get('total_max_number_of_database_components')
        num_of_db_components = int(db_components)
        zone_req = exchange.get('inputs').get('ws_req').get('zone_cidr_sizes')
        secure_zone_req = zone_req.get('secured')
        if not secure_zone_req.startswith('/'):
            exchange['errors'].append(
                'Invalid config for secure_zone_cidr :: [{secure_zone_req}]'
            )
        secure_cidr_size = int(secure_zone_req[1:])
        if num_of_db_components > 0 and secure_cidr_size <= 0:
            exchange['errors'].append(
                'Invalid size size allocated for secure zone :: [{secure_zone_req}]'
            )
        elif num_of_db_components >= 4 and secure_cidr_size > 26:
            exchange['errors'].append(
                'Insufficient CIDR size for secure zone :: [{secure_zone_req}]'
            )

    def _load_exchange(self, metadata_json, ws_requirements_json, ci_number, config):
        """ Method to create a single dictionary of data called validation exchange"""
        exchange = self._load_base_exchange(ci_number)
        exchange['inputs'] = {
            'metadata' : metadata_json,
            'ws_req': ws_requirements_json
        }
        exchange['config'] = {
            'metadata' : config['metadata_config'],
            'ws_req': config['ws_req_config']
        }
        return exchange
