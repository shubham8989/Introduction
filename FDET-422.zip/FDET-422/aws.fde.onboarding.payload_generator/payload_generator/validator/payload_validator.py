""" This is validation part"""
from payload_generator.commons.util import extract_cinumber_from_workspace_def, find_in_list
from payload_generator.commons.logger import get_logger
from payload_generator.validator.base_validator import BaseValidator

class PayloadValidator(BaseValidator):
    """ This class is for validation """

    def __init__(self):
        super().__init__()
        self.logger = get_logger("PayloadValidator")

    def start_validation(self, workspace_payload, idam_files, config=None):
        """ Method to start validation """
        self.logger.info("Starting validations")
        exchange = self._load_exchange(workspace_payload, idam_files)
        self._validate_ci_number_correct(exchange)
        self._validate_relevant_idam_files_exists(exchange)
        self._validate_ci_number_present_inside_file(exchange)
        self._validate_workspace_def(exchange, config)
        return exchange

    def _validate_ci_number_correct(self, exchange):
        """ Method to check workspace payload CI_number matches with CI_number in IDAM files"""
        try:
            ci_number = extract_cinumber_from_workspace_def(exchange.get('inputs')\
                .get('workspace_payload'))
            ci_numeric_val = ci_number[2:]
            for idam_file_name, _ in exchange.get('inputs').get('idam_files').items():
                if ci_numeric_val not in idam_file_name:
                    exchange.get('errors')\
                        .append(f'Found irrelevant IDAM file :: [{idam_file_name}]')
                    self.logger.error(f'Found irrelevant IDAM file :: [{idam_file_name}]')

        except Exception as exp:
            exchange.get('errors').append(exp)
            self.logger.error('exp')
            raise exp

    def _validate_relevant_idam_files_exists(self, exchange):
        """ Method to check all idam files are present in the input """
        try:
            exp_idam_categories = self._get_expected_idam_categories()
            actual_idam_categories = exchange.get('inputs').get('idam_files')
            for file_type in exp_idam_categories:
                file_type_val = find_in_list(actual_idam_categories, lambda x: file_type in x)
                if not file_type_val:
                    exchange.get('errors')\
                        .append(f'Could not find the IDAM file: [{file_type}]')
                    self.logger.error(f'Could not find the IDAM file: [{file_type}]')
        except Exception as exp:
            exchange.get('errors').append(exp)
            self.logger.error(exp)
            raise exp

    def _validate_ci_number_present_inside_file(self, exchange):
        """ Method to find if CI_Number is present inside file or not """
        try:
            ci_numeric_val = self._get_ci_numeric_value(exchange.get('inputs')\
                                .get('workspace_payload'))
            idam_files = exchange.get('inputs').get('idam_files')
            for _, value in idam_files.items():
                if ci_numeric_val not in value:
                    exchange.get('errors')\
                    .append(f'Could not find CI_Number :[{ci_numeric_val}] in IDAM file')
                    self.logger.error(f'Could not find CI_Number :[{ci_numeric_val}] in IDAM file')
        except Exception as exp:
            exchange.get('errors').append(exp)
            self.logger.error(exp)
            raise exp

    def _validate_workspace_def(self, exchange, config):
        """ Validate that the contents inside the workspace def is correct """
        if config is None:
            self.logger.info('Skipping the workspace def validations')
            return
        workspace_def = exchange['inputs']['workspace_payload']
        self._compare_attributes(workspace_def, config, exchange)

    def _get_ci_numeric_value(self, ws_payload):
        """ Method to fetch numeric value of CI_number from whole CI_number string"""
        ci_number = extract_cinumber_from_workspace_def(ws_payload)
        return ci_number[2:]

    def _get_expected_idam_categories(self):
        """ Method to return required IDAM files to be present in the input feed"""
        return ['Category', 'BusinessRoles', 'Applications', 'ServiceProfilesPR', 'ServiceRoles',
                'ServiceRoleHasServiceProfile', 'BusinessRoleHasServiceRole',
                'RoleAssignments', 'ProductDependencies']

    def _load_exchange(self, workspace_payload, idam_files):
        """ Method to create a single dictionary of data called validation exchange"""
        ci_number = extract_cinumber_from_workspace_def(workspace_payload)
        exchange = self._load_base_exchange(ci_number)
        exchange['inputs'] = {
            'workspace_payload' : workspace_payload,
            'idam_files': idam_files
        }
        return exchange
