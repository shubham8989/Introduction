"""Introduce the s3 repository pattern and implement all CRUD operations"""
import os
from abc import ABC
from payload_generator.clients.aws_clients import get_s3_bucket
from payload_generator.commons.errors import OperationsException
from payload_generator.commons.logger import get_logger

class S3BaseReporitory(ABC):
    """Abstract class for s3 base repository operations"""
    def __init__(self, bucket_name):
        super().__init__()
        self.s3_bucket = get_s3_bucket(bucket_name)
        self.logger = get_logger('S3BaseReporitory')

    def save_file_in_folder_s3(self, folder_name, object_name, file_object):
        """create a file in s3 bucket - under a folder.Pass the file object"""
        if self.bucket_folder_exists_s3(folder_name):
            try:
                self.s3_bucket.upload_fileobj(file_object, f'{folder_name}/{object_name}')
            except Exception as exp:
                errors = f'Save File: Error while saving file to S3'
                self.logger.error(f'Found errors :: {exp}')
                raise OperationsException(f'{exp}')
        else:
            errors = f'Save File: Folder [{folder_name}] does not exists'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'{errors}')

    def save_file_s3(self, object_name, file_object):
        """create a file in s3 bucket. Pass the file object"""
        try:
            self.s3_bucket.upload_fileobj(file_object, f'{object_name}')
        except Exception as exp:
            errors = f'Save File: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')

    def update_file_in_folder_s3(self, folder_name, object_name, file_object):
        """update an existing file in s3 bucket under a folder.Pass the file object"""
        if self.bucket_folder_exists_s3(folder_name):
            try:
                self.s3_bucket.upload_fileobj(file_object, f'{folder_name}/{object_name}')
            except Exception as exp:
                errors = f'Update file in folder: Error while saving file to S3'
                self.logger.error(f'Found errors :: {exp} - {errors}')
                raise OperationsException(f'{exp} - {errors}')
        else:
            errors = f'Update File: Folder [{folder_name}] does not exists'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'{errors}')

    def update_file_s3(self, object_name, file_object):
        """create a file in s3 bucket .Pass the file object"""
        try:
            self.s3_bucket.upload_fileobj(file_object, f'{object_name}')
        except Exception as exp:
            errors = f'Update File: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')

    def delete_file_from_folder_s3(self, folder_name, object_name):
        """Delete a file in s3 bucket from a folder """
        if self.bucket_folder_exists_s3(folder_name):
            file_name = f'{folder_name}/{object_name}'
            try:
                self.s3_bucket.objects.filter(Prefix=file_name).delete()
            except Exception as exp:
                errors = f'Update file: Error while saving file to S3'
                self.logger.error(f'Found errors :: {exp} - {errors}')
                raise OperationsException(f'{exp} - {errors}')
        else:
            errors = f'Delete File: Folder [{folder_name}] does not exists'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'{errors}')

    def delete_file_s3(self, object_name):
        """delete a file in s3 bucket """
        try:
            self.s3_bucket.objects.filter(Prefix=object_name).delete()
        except Exception as exp:
            errors = f'Update File: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')

    def search_file_s3(self, folder_name=None, object_name=None):
        """search  a file or folder in s3 bucket """
        if folder_name is None and object_name is None:
            errors = f'Search File: Either folder or Object name should be present'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'{errors}')
        if folder_name is not None:
            if list(folder_name)[-1] != '/':
                search_name = f'{folder_name}/'
            if object_name is not None:
                search_name = f'{search_name}{object_name}'
        else:
            search_name = f'{object_name}'
        return_array = []
        try:
            for key in self.s3_bucket.objects.all():
                if folder_name and object_name is None:
                    condition = (search_name in key.key)
                else:
                    condition = (search_name == key.key)
                if condition:
                    return_array.append(key.key)
        except Exception as exp:
            errors = f'Update file in folder: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')
        return return_array

    def create_folder_s3(self, folder_name):
        """create a folder in s3 bucket """
        try:
            self.s3_bucket.put_object(Key=f'{folder_name}/')
        except Exception as exp:
            errors = f'Create folder: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')

    def delete_folder_s3(self, folder_name):
        """delete a folder from s3 bucket """
        if self.bucket_folder_exists_s3(folder_name):
            folder = f'{folder_name}/'
            try:
                self.s3_bucket.objects.filter(Prefix=folder).delete()
            except Exception as exp:
                errors = f'delete  folder: Error while saving file to S3'
                self.logger.error(f'Found errors :: {exp} - {errors}')
                raise OperationsException(f'{exp} - {errors}')
        else:
            errors = f'Delete folder: Folder [{folder_name}] does not exists'
            self.logger.error(f'Found errors :: {errors}')
            raise OperationsException(f'{errors}')

    def bucket_folder_exists_s3(self, folder_name):
        """check whether a folder in s3 bucket """
        if list(folder_name)[-1] != '/':
            folder_name += '/'
        try:
            s3_objects = self.s3_bucket.objects.all().filter(Prefix=f'{folder_name}/')
            if s3_objects:
                return True
        except Exception as exp:
            errors = f'Update file in folder: Error while saving file to S3'
            self.logger.error(f'Found errors :: {exp} - {errors}')
            raise OperationsException(f'{exp} - {errors}')
        return False


class WorkspaceDefinitionRepository(S3BaseReporitory):
    """Class for s3 Workspace repository"""

    def __init__(self):
        bucket_name = os.getenv('WORKSPACE_DEFINITION_REPO', 'workspace-def-repo')
        self.logger = get_logger('WorkspaceDefinitionRepository')
        super().__init__(bucket_name)

class DesignDocsRepository(S3BaseReporitory):
    """Class for s3 design repository"""
    def __init__(self):
        bucket_name = os.getenv('DESIGN_DOC_REPO', 'design-doc-repo')
        self.logger = get_logger('DesignDocsRepository')
        super().__init__(bucket_name)

class IDAMResourcesRepository(S3BaseReporitory):
    """Class for s3 IDAM repository"""
    def __init__(self):
        bucket_name = os.getenv('IDAM_RESOURCES_REPO', 'idam-resources-repo')
        self.logger = get_logger('IDAMResourcesRepository')
        super().__init__(bucket_name)

class PayloadsRepository(S3BaseReporitory):
    """Class for s3 Output Payload repository"""
    def __init__(self):
        bucket_name = os.getenv('PAYLOADS_REPO', 'payload-repo')
        self.logger = get_logger('IPayloadsRepository')
        super().__init__(bucket_name)
