""" The module for S3 management """
import os
import boto3
from payload_generator.commons.errors import ConnectivityException
from payload_generator.commons.logger import get_logger

class S3Controller:
    """ The S3 controller class """

    def __init__(self):
        """ Default constructor """
        super().__init__()
        self.logger = get_logger('S3Controller')
        self.bucket_name = os.getenv('S3_Code_Bucket', 'fde-onboarding-bucket')

    def move_to_s3(self, file_src, ci_number):
        """ Moves a given file to the folder [ci_number] """
        try:
            s3_client = boto3.resource('s3')
            file_name = os.path.basename(file_src)
            s3_client.Bucket(self.bucket_name).upload_file(file_src, f'{ci_number}/{file_name}')
        except ConnectivityException as exp:
            self.logger.error(exp)
