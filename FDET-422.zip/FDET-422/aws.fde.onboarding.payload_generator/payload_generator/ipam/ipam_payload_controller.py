""" The IPAM Payload management module """
import json

class IPAMPayloadController:
    """ IPAM Payoad Design """

    def generate_ipam_payload(self, design_src, destination):
        """ Generate the IPAM Payload """
        ws_design = json.load(open(design_src, 'r'))
        ipam_payload = ws_design.get('zone_cidr_sizes')
        with open(f'{destination}/ipam.json', 'w') as ipam_file:
            json.dump(ipam_payload, ipam_file)
